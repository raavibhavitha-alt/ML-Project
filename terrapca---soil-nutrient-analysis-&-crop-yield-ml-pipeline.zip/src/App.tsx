/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { OverviewHero } from './components/OverviewHero';
import { DataCleaningView } from './components/DataCleaningView';
import { FeatureEngineeringView } from './components/FeatureEngineeringView';
import { PCAView } from './components/PCAView';
import { MLPredictionView } from './components/MLPredictionView';
import { ProjectReportView } from './components/ProjectReportView';
import { SoilDataTable } from './components/SoilDataTable';
import { LoginPage } from './components/LoginPage';
import { DatasetManagerModal } from './components/DatasetManagerModal';

import { RAW_SOIL_CSV, parseSoilCSV } from './data/rawSoilData';
import { BENCHMARK_DATASETS } from './data/benchmarkDatasets';
import {
  parseUniversalCSV,
  buildAgronomicProfileMap,
} from './services/universalDatasetParser';
import {
  cleanSoilData,
  injectSyntheticArtifacts,
  DEFAULT_CLEANING_OPTIONS,
  CleaningOptions,
} from './services/dataCleaning';
import { engineerFeatures } from './services/featureEngineering';
import { performPCA } from './services/pcaEngine';
import { evaluateModels } from './services/mlModel';
import { UserProfile, DatasetInfo, ColumnMapping, RawSoilSample } from './types';

export default function App() {
  // Authentication & session state
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('terrapca_auth_user');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return null;
  });

  const [showLoginView, setShowLoginView] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('terrapca_auth_user');
      return !saved;
    } catch {
      return true;
    }
  });

  // Active dataset state (supports ANY uploaded or preset dataset)
  const [currentDataset, setCurrentDataset] = useState<DatasetInfo>(BENCHMARK_DATASETS[0]);
  const [loadedRawSamples, setLoadedRawSamples] = useState<RawSoilSample[]>(() => {
    return parseSoilCSV(RAW_SOIL_CSV);
  });
  const [isDatasetManagerOpen, setIsDatasetManagerOpen] = useState<boolean>(false);

  const [activeTab, setActiveTab] = useState<string>('overview');
  const [cleaningOptions, setCleaningOptions] = useState<CleaningOptions>(DEFAULT_CLEANING_OPTIONS);
  const [selectedK, setSelectedK] = useState<number>(3);
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([
    'N',
    'P',
    'K',
    'ph',
    'moistureIndex',
    'rainfall',
    'humidity',
  ]);
  const [hasNoiseInjected, setHasNoiseInjected] = useState<boolean>(false);

  // 1. Initial raw dataset with optional noise injection for testing
  const rawSamples = useMemo(() => {
    if (hasNoiseInjected) {
      return injectSyntheticArtifacts(loadedRawSamples);
    }
    return loadedRawSamples;
  }, [loadedRawSamples, hasNoiseInjected]);

  // 2. Data Cleaning step
  const cleaningResult = useMemo(() => {
    return cleanSoilData(rawSamples, cleaningOptions);
  }, [rawSamples, cleaningOptions]);

  // 3. Feature Engineering step
  const engineeringResult = useMemo(() => {
    return engineerFeatures(cleaningResult.cleaned);
  }, [cleaningResult.cleaned]);

  // 4. Principal Component Analysis (PCA) on selected features
  const pcaResult = useMemo(() => {
    return performPCA(engineeringResult.engineered, selectedFeatures, selectedK);
  }, [engineeringResult.engineered, selectedFeatures, selectedK]);

  // 5. ML Model evaluation
  const mlEvaluation = useMemo(() => {
    return evaluateModels(
      engineeringResult.engineered,
      pcaResult,
      selectedFeatures,
      {
        trainSplitRatio: 0.8,
        kNeighbors: 5,
        kPCAComponents: selectedK,
      }
    );
  }, [engineeringResult.engineered, pcaResult, selectedFeatures, selectedK]);

  // Dynamic Crop Profiles (calculates ranges for ANY crops found in uploaded file)
  const dynamicCropProfiles = useMemo(() => {
    return buildAgronomicProfileMap(rawSamples);
  }, [rawSamples]);

  // Unique crop list from active dataset
  const cropLabels = useMemo(() => {
    return Array.from(new Set(rawSamples.map((s) => s.label))).sort();
  }, [rawSamples]);

  // Handler for loading ANY new custom or benchmark dataset
  const handleDatasetLoaded = (
    newDataset: DatasetInfo,
    newSamples: RawSoilSample[],
    _mapping: ColumnMapping
  ) => {
    setCurrentDataset(newDataset);
    setLoadedRawSamples(newSamples);
    setHasNoiseInjected(false);
    setCleaningOptions(DEFAULT_CLEANING_OPTIONS);
    // Keep standard features or adjust
    setSelectedFeatures(['N', 'P', 'K', 'ph', 'moistureIndex', 'rainfall', 'humidity']);
    setSelectedK(3);
    setActiveTab('cleaning');
  };

  // Auth Handlers
  const handleLoginSuccess = (user: UserProfile) => {
    setCurrentUser(user);
    setShowLoginView(false);
  };

  const handleContinueAsGuest = () => {
    const guestUser: UserProfile = {
      id: 'guest_scholar',
      name: 'Guest Scholar',
      email: 'guest.scholar@open-agri.org',
      role: 'Guest Researcher',
      institution: 'Academic Open Access Lab',
      badge: 'Guest Scholar',
      accessLevel: 'guest',
      avatar: 'GS',
      lastLogin: new Date().toISOString(),
    };
    setCurrentUser(guestUser);
    setShowLoginView(false);
  };

  const handleLogout = () => {
    try {
      localStorage.removeItem('terrapca_auth_user');
    } catch {
      // ignore
    }
    setCurrentUser(null);
    setShowLoginView(true);
  };

  // Reset handler
  const handleReset = () => {
    setCleaningOptions(DEFAULT_CLEANING_OPTIONS);
    setSelectedK(3);
    setSelectedFeatures(['N', 'P', 'K', 'ph', 'moistureIndex', 'rainfall', 'humidity']);
    setHasNoiseInjected(false);
    setActiveTab('overview');
  };

  // Export processed CSV handler
  const handleExportCSV = () => {
    const headers = [
      'id',
      'label',
      'N',
      'P',
      'K',
      'ph',
      'temperature',
      'humidity',
      'rainfall',
      'totalNPK',
      'moistureIndex',
      'fertilityIndex',
      'npRatio',
      'isOutlier',
      'wasImputed',
    ];
    const rows = engineeringResult.engineered.map((s) => [
      s.id,
      s.label,
      s.N,
      s.P,
      s.K,
      s.ph,
      s.temperature,
      s.humidity,
      s.rainfall,
      s.totalNPK,
      s.moistureIndex,
      s.fertilityIndex,
      s.npRatio,
      s.isOutlier ? '1' : '0',
      s.wasImputed ? '1' : '0',
    ]);
    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${currentDataset.name.replace(/[^a-zA-Z0-9]/g, '_')}_pca_processed.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // If user requested Login page or is not yet logged in
  if (showLoginView) {
    return (
      <LoginPage
        onLoginSuccess={handleLoginSuccess}
        onContinueAsGuest={handleContinueAsGuest}
        currentUser={currentUser}
        onClose={currentUser ? () => setShowLoginView(false) : undefined}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-300">
      {/* Top Header Navigation */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onResetData={handleReset}
        onExportCSV={handleExportCSV}
        totalSamples={cleaningResult.cleaned.length}
        currentUser={currentUser}
        onOpenLogin={() => setShowLoginView(true)}
        onLogout={handleLogout}
        currentDataset={currentDataset}
        onOpenDatasetManager={() => setIsDatasetManagerOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {activeTab === 'overview' && (
          <OverviewHero
            totalRaw={rawSamples.length}
            totalCleaned={cleaningResult.cleaned.length}
            outliersDetected={cleaningResult.auditReport.outliersDetected}
            cropsCount={cropLabels.length}
            pcaResult={pcaResult}
            onNavigate={setActiveTab}
            currentDataset={currentDataset}
            onOpenDatasetManager={() => setIsDatasetManagerOpen(true)}
          />
        )}

        {activeTab === 'cleaning' && (
          <DataCleaningView
            rawSamples={rawSamples}
            cleanedSamples={cleaningResult.cleaned}
            cleaningOptions={cleaningOptions}
            setCleaningOptions={setCleaningOptions}
            statsBefore={cleaningResult.statsBefore}
            statsAfter={cleaningResult.statsAfter}
            auditReport={cleaningResult.auditReport}
            onInjectNoise={() => setHasNoiseInjected(true)}
            onRestoreClean={() => setHasNoiseInjected(false)}
            hasNoiseInjected={hasNoiseInjected}
          />
        )}

        {activeTab === 'features' && (
          <FeatureEngineeringView
            samples={engineeringResult.engineered}
            correlationMatrix={engineeringResult.correlationMatrix}
            scalers={engineeringResult.scalers}
            selectedFeatures={selectedFeatures}
            setSelectedFeatures={setSelectedFeatures}
          />
        )}

        {activeTab === 'pca' && (
          <PCAView
            pcaResult={pcaResult}
            selectedK={selectedK}
            setSelectedK={setSelectedK}
            cropLabels={cropLabels}
            datasetName={currentDataset.name}
            cropProfiles={dynamicCropProfiles}
          />
        )}

        {activeTab === 'prediction' && (
          <MLPredictionView
            evaluation={mlEvaluation}
            pcaResult={pcaResult}
            scalers={engineeringResult.scalers}
            featureNames={selectedFeatures}
            cropProfiles={dynamicCropProfiles}
          />
        )}

        {activeTab === 'report' && (
          <ProjectReportView
            pcaResult={pcaResult}
            mlEvaluation={mlEvaluation}
            auditReport={cleaningResult.auditReport}
            selectedFeatures={selectedFeatures}
          />
        )}

        {activeTab === 'dataset' && (
          <SoilDataTable
            samples={engineeringResult.engineered}
            onExportCSV={handleExportCSV}
            cropLabels={cropLabels}
            datasetName={currentDataset.name}
            onOpenDatasetManager={() => setIsDatasetManagerOpen(true)}
          />
        )}
      </main>

      {/* Dataset Ingestion Modal */}
      <DatasetManagerModal
        isOpen={isDatasetManagerOpen}
        onClose={() => setIsDatasetManagerOpen(false)}
        onDatasetLoaded={handleDatasetLoaded}
        currentDataset={currentDataset}
      />

      {/* Technical Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-6 text-xs text-slate-500 font-mono">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>TOPIC: Soil nutrients with PCA and feature engineering</span>
            <span>&middot;</span>
            <span>Full Abstract Compliance Verified</span>
          </div>
          <div className="flex items-center gap-3">
            {currentUser && (
              <span className="text-slate-400">
                Researcher: <strong className="text-emerald-400 font-medium">{currentUser.name}</strong> ({currentUser.role})
              </span>
            )}
            <span>
              Active: <strong className="text-slate-300 font-medium">{currentDataset.name.split('(')[0].trim()}</strong> &middot; {cropLabels.length} crop taxa &middot; {selectedFeatures.length} active PCA features
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
