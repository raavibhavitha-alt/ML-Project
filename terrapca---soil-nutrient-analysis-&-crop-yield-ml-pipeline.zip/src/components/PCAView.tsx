import React, { useState, useMemo } from 'react';
import {
  Cpu,
  BarChart3,
  LineChart,
  Compass,
  Sparkles,
  Layers,
  Sliders,
  CheckCircle2,
  TrendingUp,
  SlidersHorizontal,
  Table,
  Filter,
} from 'lucide-react';
import { PCAResult, CropAgronomicProfile } from '../types';
import { CROP_PROFILES } from '../data/rawSoilData';

interface PCAViewProps {
  pcaResult: PCAResult;
  selectedK: number;
  setSelectedK: (k: number) => void;
  cropLabels: string[];
  datasetName?: string;
  cropProfiles?: Record<string, CropAgronomicProfile>;
}

export const PCAView: React.FC<PCAViewProps> = ({
  pcaResult,
  selectedK,
  setSelectedK,
  cropLabels,
  datasetName,
  cropProfiles,
}) => {
  // Graph Mode Selector
  const [activeGraphTab, setActiveGraphTab] = useState<'dashboard' | 'bar' | 'line' | 'biplot'>('dashboard');
  const [selectedComponentForBar, setSelectedComponentForBar] = useState<'pc1' | 'pc2' | 'pc3'>('pc1');
  const [showVectors, setShowVectors] = useState<boolean>(true);
  const [selectedCropFilter, setSelectedCropFilter] = useState<string>('all');
  const [activeAxisPair, setActiveAxisPair] = useState<'pc1-pc2' | 'pc1-pc3' | 'pc2-pc3'>('pc1-pc2');
  const [hoveredPoint, setHoveredPoint] = useState<{
    id: number;
    label: string;
    pcX: number;
    pcY: number;
    original: any;
  } | null>(null);

  const allProfiles = cropProfiles || CROP_PROFILES;

  // 1. Calculate Crop-wise Centroids for the active dataset file
  const cropCentroids = useMemo(() => {
    const map: Record<string, { count: number; sumPC1: number; sumPC2: number; sumPC3: number }> = {};
    for (const sample of pcaResult.projectedData) {
      if (!map[sample.label]) {
        map[sample.label] = { count: 0, sumPC1: 0, sumPC2: 0, sumPC3: 0 };
      }
      map[sample.label].count += 1;
      map[sample.label].sumPC1 += sample.pc1;
      map[sample.label].sumPC2 += sample.pc2;
      map[sample.label].sumPC3 += sample.pc3;
    }

    return Object.entries(map).map(([crop, data]) => ({
      crop,
      avgPC1: Number((data.sumPC1 / data.count).toFixed(2)),
      avgPC2: Number((data.sumPC2 / data.count).toFixed(2)),
      avgPC3: Number((data.sumPC3 / data.count).toFixed(2)),
      count: data.count,
      color: allProfiles[crop]?.color || '#10B981',
      displayName: allProfiles[crop]?.displayName || crop.toUpperCase(),
    }));
  }, [pcaResult.projectedData, allProfiles]);

  // 2. Extents for SVG 2D Biplot
  const { minX, maxX, minY, maxY } = useMemo(() => {
    let minX = Infinity;
    let maxX = -Infinity;
    let minY = Infinity;
    let maxY = -Infinity;

    for (const p of pcaResult.projectedData) {
      let x = p.pc1;
      let y = p.pc2;
      if (activeAxisPair === 'pc1-pc3') {
        x = p.pc1;
        y = p.pc3;
      } else if (activeAxisPair === 'pc2-pc3') {
        x = p.pc2;
        y = p.pc3;
      }

      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
    }

    const padX = (maxX - minX) * 0.15 || 1;
    const padY = (maxY - minY) * 0.15 || 1;
    return {
      minX: minX - padX,
      maxX: maxX + padX,
      minY: minY - padY,
      maxY: maxY + padY,
    };
  }, [pcaResult.projectedData, activeAxisPair]);

  const svgWidth = 700;
  const svgHeight = 440;
  const padding = 50;

  const toSvgX = (x: number) =>
    padding + ((x - minX) / (maxX - minX || 1)) * (svgWidth - 2 * padding);
  const toSvgY = (y: number) =>
    svgHeight - padding - ((y - minY) / (maxY - minY || 1)) * (svgHeight - 2 * padding);

  const originX = toSvgX(0);
  const originY = toSvgY(0);

  const visibleSamples = useMemo(() => {
    if (selectedCropFilter === 'all') return pcaResult.projectedData;
    return pcaResult.projectedData.filter((s) => s.label === selectedCropFilter);
  }, [pcaResult.projectedData, selectedCropFilter]);

  let xLabel = 'PC1';
  let yLabel = 'PC2';
  let xVar = pcaResult.explainedVariance[0] ?? 0;
  let yVar = pcaResult.explainedVariance[1] ?? 0;

  if (activeAxisPair === 'pc1-pc3') {
    xLabel = 'PC1';
    yLabel = 'PC3';
    xVar = pcaResult.explainedVariance[0] ?? 0;
    yVar = pcaResult.explainedVariance[2] ?? 0;
  } else if (activeAxisPair === 'pc2-pc3') {
    xLabel = 'PC2';
    yLabel = 'PC3';
    xVar = pcaResult.explainedVariance[1] ?? 0;
    yVar = pcaResult.explainedVariance[2] ?? 0;
  }

  // Loadings for active selected component
  const activeLoadings = useMemo(() => {
    return pcaResult.loadings
      .map((l) => ({
        feature: l.feature,
        value: (l as any)[selectedComponentForBar] ?? 0,
      }))
      .sort((a, b) => b.value - a.value);
  }, [pcaResult.loadings, selectedComponentForBar]);

  return (
    <div className="space-y-8">
      {/* Title & Active Dataset Indicator */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-purple-400 uppercase tracking-wider">
              Step 3 &middot; Abstract Requirement
            </span>
            {datasetName && (
              <span className="text-[11px] px-2 py-0.5 rounded bg-purple-950/60 border border-purple-800/60 text-purple-300 font-mono">
                Dataset: {datasetName.split('(')[0].trim()} ({cropLabels.length} Crops)
              </span>
            )}
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-0.5">
            Principal Component Analysis (PCA) & Major Factors
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-3xl mt-1">
            Dimensionality reduction transforming correlated soil attributes into principal components while preserving maximum variation. Inspect via interactive Line Graphs, Bar Graphs, and Biplot Projections.
          </p>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setActiveGraphTab('dashboard')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeGraphTab === 'dashboard'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Overview</span>
            </button>

            <button
              onClick={() => setActiveGraphTab('bar')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeGraphTab === 'bar'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Bar Graphs</span>
            </button>

            <button
              onClick={() => setActiveGraphTab('line')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeGraphTab === 'line'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <LineChart className="w-3.5 h-3.5" />
              <span>Line Graphs</span>
            </button>

            <button
              onClick={() => setActiveGraphTab('biplot')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeGraphTab === 'biplot'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Compass className="w-3.5 h-3.5" />
              <span>2D Biplot</span>
            </button>
          </div>
        </div>
      </div>

      {/* Major Factors Cards (Always visible as foundation) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-400" />
            <h3 className="text-base font-bold text-white">
              Major Factors Identified for {datasetName ? datasetName.split('(')[0].trim() : 'Current Dataset'}
            </h3>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Computed Dynamically from Eigendecomposition
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {pcaResult.majorFactors.slice(0, 3).map((factor, idx) => (
            <div
              key={factor.component}
              className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3 flex flex-col justify-between hover:border-slate-700 transition-colors"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded text-xs font-mono font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                    {factor.component} &middot; Factor {idx + 1}
                  </span>
                  <span className="text-xs font-mono text-emerald-400 font-bold">
                    {factor.variancePct}% Variance
                  </span>
                </div>
                <h4 className="text-sm font-semibold text-white">{factor.name}</h4>
                <p className="text-xs text-slate-300 leading-relaxed font-sans">
                  {factor.agronomicDescription}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800/80 space-y-2 text-xs font-mono">
                <div>
                  <span className="text-slate-500 text-[10px] uppercase block">Dominant Drivers in File:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {factor.topPositiveDrivers.map((d) => (
                      <span
                        key={d.feature}
                        className="px-1.5 py-0.5 bg-slate-950 text-cyan-300 rounded border border-slate-800 text-[11px]"
                      >
                        +{d.feature} ({d.loading > 0 ? `+${d.loading}` : d.loading})
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-slate-500 text-[10px] uppercase block">Representative Crop Niches:</span>
                  <span className="text-slate-300 text-[11px] font-sans">
                    {factor.representativeCrops.join(', ') || 'General Crop Matrix'}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SECTION: BAR GRAPH VIEW */}
      {/* ========================================================================= */}
      {(activeGraphTab === 'bar' || activeGraphTab === 'dashboard') && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-emerald-400" />
              <div>
                <h3 className="text-base font-bold text-white">PCA Major Factor Loadings — Bar Graph</h3>
                <p className="text-xs text-slate-400">
                  Visualizing how strongly each soil parameter weights into Principal Components for the active crop dataset.
                </p>
              </div>
            </div>

            {/* Component Picker Buttons */}
            <div className="flex items-center gap-2 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
              <span className="text-slate-400 px-2 font-mono">Component:</span>
              {(['pc1', 'pc2', 'pc3'] as const).map((pc) => (
                <button
                  key={pc}
                  onClick={() => setSelectedComponentForBar(pc)}
                  className={`px-3 py-1 rounded font-mono font-bold uppercase transition-all ${
                    selectedComponentForBar === pc
                      ? 'bg-emerald-500 text-slate-950 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {pc.toUpperCase()} ({pcaResult.explainedVariance[parseInt(pc.slice(2), 10) - 1] ?? 0}%)
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Diverging Horizontal Bar Graph for Loadings */}
            <div className="lg:col-span-7 bg-slate-950 p-4 rounded-xl border border-slate-800/80 space-y-3">
              <div className="flex justify-between items-center text-xs font-mono text-slate-400 border-b border-slate-800 pb-2">
                <span>Feature in Active File</span>
                <span>Negative Loading &larr; 0 &rarr; Positive Loading</span>
              </div>

              <div className="space-y-2 pt-1">
                {activeLoadings.map((item) => {
                  const val = item.value;
                  const isPositive = val >= 0;
                  const absPct = Math.min(100, Math.abs(val) * 160); // scale factor

                  return (
                    <div key={item.feature} className="space-y-1">
                      <div className="flex justify-between text-xs font-mono">
                        <span className="text-slate-200 font-medium">{item.feature}</span>
                        <span
                          className={`font-bold ${
                            isPositive ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {isPositive ? `+${val}` : val}
                        </span>
                      </div>

                      {/* Diverging Bar */}
                      <div className="grid grid-cols-2 gap-1 h-3 bg-slate-900 rounded overflow-hidden border border-slate-800">
                        {/* Negative side */}
                        <div className="flex justify-end bg-slate-900/50">
                          {!isPositive && (
                            <div
                              className="h-full bg-rose-500/80 rounded-l transition-all duration-300"
                              style={{ width: `${absPct}%` }}
                            />
                          )}
                        </div>
                        {/* Positive side */}
                        <div className="flex justify-start bg-slate-900/50">
                          {isPositive && (
                            <div
                              className="h-full bg-emerald-400 rounded-r transition-all duration-300"
                              style={{ width: `${absPct}%` }}
                            />
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Right: Crop Distribution along Active PC Bar Chart */}
            <div className="lg:col-span-5 bg-slate-950 p-4 rounded-xl border border-slate-800/80 space-y-3">
              <div className="flex justify-between items-center text-xs font-mono text-slate-400 border-b border-slate-800 pb-2">
                <span>Crop Average {selectedComponentForBar.toUpperCase()}</span>
                <span>{cropCentroids.length} Crops</span>
              </div>

              <div className="space-y-2 max-h-[340px] overflow-y-auto pr-1">
                {[...cropCentroids]
                  .sort((a, b) => {
                    const key = selectedComponentForBar === 'pc1' ? 'avgPC1' : selectedComponentForBar === 'pc2' ? 'avgPC2' : 'avgPC3';
                    return b[key] - a[key];
                  })
                  .map((c) => {
                    const val =
                      selectedComponentForBar === 'pc1'
                        ? c.avgPC1
                        : selectedComponentForBar === 'pc2'
                        ? c.avgPC2
                        : c.avgPC3;
                    const isPositive = val >= 0;
                    const barWidth = Math.min(100, Math.abs(val) * 20);

                    return (
                      <div key={c.crop} className="space-y-0.5">
                        <div className="flex justify-between text-[11px] font-mono">
                          <span className="text-slate-300 flex items-center gap-1.5 capitalize">
                            <span
                              className="w-2 h-2 rounded-full inline-block"
                              style={{ backgroundColor: c.color }}
                            />
                            {c.displayName}
                          </span>
                          <span className={isPositive ? 'text-cyan-400 font-bold' : 'text-amber-400 font-bold'}>
                            {isPositive ? `+${val}` : val}
                          </span>
                        </div>

                        <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden flex border border-slate-800">
                          <div
                            className="h-full rounded-full transition-all duration-300"
                            style={{
                              width: `${Math.max(4, barWidth)}%`,
                              backgroundColor: c.color,
                            }}
                          />
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SECTION: LINE GRAPH VIEW */}
      {/* ========================================================================= */}
      {(activeGraphTab === 'line' || activeGraphTab === 'dashboard') && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div className="flex items-center gap-2">
              <LineChart className="w-5 h-5 text-cyan-400" />
              <div>
                <h3 className="text-base font-bold text-white">PCA Scree & Variance Curves — Line Graph</h3>
                <p className="text-xs text-slate-400">
                  Continuous explained variance line graph and multi-component loading trajectory for the active dataset.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 text-xs font-mono">
              <span className="flex items-center gap-1 text-emerald-400">
                <span className="w-3 h-0.5 bg-emerald-400 inline-block" />
                Cumulative Explained %
              </span>
              <span className="flex items-center gap-1 text-cyan-400">
                <span className="w-3 h-0.5 bg-cyan-400 inline-block" />
                Individual PC %
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 1. Scree Plot Line Graph (SVG) */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 space-y-2">
              <div className="flex justify-between items-center text-xs font-mono text-slate-400 mb-2">
                <span>Cumulative Variance Line Graph & Elbow Point</span>
                <span className="text-emerald-400 font-bold">
                  Retained at k={selectedK}: {pcaResult.cumulativeVariance[selectedK - 1] ?? 0}%
                </span>
              </div>

              {/* Responsive SVG Line Chart */}
              <div className="w-full overflow-hidden">
                <svg viewBox="0 0 500 240" className="w-full h-auto select-none font-mono">
                  {/* Grid Lines */}
                  {[0, 25, 50, 75, 100].map((tick) => {
                    const y = 200 - (tick / 100) * 160;
                    return (
                      <g key={tick}>
                        <line x1="40" y1={y} x2="480" y2={y} stroke="#1E293B" strokeWidth="1" strokeDasharray="3 3" />
                        <text x="32" y={y + 3} fill="#64748B" fontSize="9" textAnchor="end">
                          {tick}%
                        </text>
                      </g>
                    );
                  })}

                  {/* 80% and 95% Reference Lines */}
                  <line x1="40" y1={200 - 0.8 * 160} x2="480" y2={200 - 0.8 * 160} stroke="#059669" strokeWidth="1" strokeDasharray="4 2" opacity="0.6" />
                  <text x="475" y={200 - 0.8 * 160 - 4} fill="#10B981" fontSize="9" textAnchor="end">
                    80% Threshold
                  </text>

                  {/* X Axis Ticks */}
                  {pcaResult.explainedVariance.slice(0, 6).map((_, idx) => {
                    const x = 50 + idx * 75;
                    return (
                      <g key={idx}>
                        <text x={x} y="222" fill="#94A3B8" fontSize="10" textAnchor="middle">
                          PC{idx + 1}
                        </text>
                        <line x1={x} y1="200" x2={x} y2="204" stroke="#475569" strokeWidth="1" />
                      </g>
                    );
                  })}

                  {/* Cumulative Variance Polyline with Gradient Fill */}
                  {(() => {
                    const points = pcaResult.cumulativeVariance.slice(0, 6).map((v, i) => ({
                      x: 50 + i * 75,
                      y: 200 - (v / 100) * 160,
                      val: v,
                    }));

                    const pathD = points.reduce((acc, pt, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`, '');
                    const areaD = `${pathD} L ${points[points.length - 1].x} 200 L ${points[0].x} 200 Z`;

                    return (
                      <g>
                        <defs>
                          <linearGradient id="cumGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#10B981" stopOpacity="0.3" />
                            <stop offset="100%" stopColor="#10B981" stopOpacity="0.0" />
                          </linearGradient>
                        </defs>
                        <path d={areaD} fill="url(#cumGrad)" />
                        <path d={pathD} fill="none" stroke="#10B981" strokeWidth="2.5" />

                        {points.map((pt, i) => (
                          <g key={i}>
                            <circle
                              cx={pt.x}
                              cy={pt.y}
                              r={i + 1 === selectedK ? 6 : 4}
                              fill={i + 1 === selectedK ? '#059669' : '#10B981'}
                              stroke="#0F172A"
                              strokeWidth="2"
                            />
                            <text x={pt.x} y={pt.y - 8} fill="#34D399" fontSize="10" fontWeight="bold" textAnchor="middle">
                              {pt.val}%
                            </text>
                          </g>
                        ))}
                      </g>
                    );
                  })()}

                  {/* Individual Variance Polyline (Cyan) */}
                  {(() => {
                    const indPoints = pcaResult.explainedVariance.slice(0, 6).map((v, i) => ({
                      x: 50 + i * 75,
                      y: 200 - (v / 100) * 160,
                      val: v,
                    }));
                    const indD = indPoints.reduce((acc, pt, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`, '');

                    return (
                      <g>
                        <path d={indD} fill="none" stroke="#06B6D4" strokeWidth="2" strokeDasharray="3 2" />
                        {indPoints.map((pt, i) => (
                          <circle key={i} cx={pt.x} cy={pt.y} r="3" fill="#06B6D4" />
                        ))}
                      </g>
                    );
                  })()}
                </svg>
              </div>

              {/* Slider for k */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">Adjust Retained Components (k):</span>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min="2"
                    max={Math.min(6, pcaResult.explainedVariance.length)}
                    value={selectedK}
                    onChange={(e) => setSelectedK(parseInt(e.target.value, 10))}
                    className="accent-emerald-400 h-1.5 w-32 cursor-pointer"
                  />
                  <span className="text-emerald-400 font-bold text-sm">k = {selectedK}</span>
                </div>
              </div>
            </div>

            {/* 2. Multi-Component Feature Profile Line Graph */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 space-y-2">
              <div className="flex justify-between items-center text-xs font-mono text-slate-400 mb-2">
                <span>Multi-Component Factor Loadings Trajectory</span>
                <div className="flex items-center gap-2">
                  <span className="text-emerald-400">&bull; PC1</span>
                  <span className="text-cyan-400">&bull; PC2</span>
                  <span className="text-purple-400">&bull; PC3</span>
                </div>
              </div>

              <div className="w-full overflow-hidden">
                <svg viewBox="0 0 500 240" className="w-full h-auto select-none font-mono">
                  {/* Zero Baseline */}
                  <line x1="40" y1="120" x2="480" y2="120" stroke="#475569" strokeWidth="1.2" strokeDasharray="4 2" />
                  <text x="32" y="123" fill="#64748B" fontSize="9" textAnchor="end">
                    0.0
                  </text>
                  <line x1="40" y1="40" x2="480" y2="40" stroke="#1E293B" strokeWidth="1" strokeDasharray="2 2" />
                  <text x="32" y="43" fill="#64748B" fontSize="9" textAnchor="end">
                    +0.6
                  </text>
                  <line x1="40" y1="200" x2="480" y2="200" stroke="#1E293B" strokeWidth="1" strokeDasharray="2 2" />
                  <text x="32" y="203" fill="#64748B" fontSize="9" textAnchor="end">
                    -0.6
                  </text>

                  {/* Features along X-Axis */}
                  {pcaResult.loadings.map((l, idx) => {
                    const count = pcaResult.loadings.length;
                    const x = 50 + (idx / Math.max(1, count - 1)) * 410;
                    return (
                      <g key={l.feature}>
                        <line x1={x} y1="35" x2={x} y2="205" stroke="#1E293B" strokeWidth="1" strokeDasharray="2 2" opacity="0.4" />
                        <text x={x} y="222" fill="#94A3B8" fontSize="9" textAnchor="middle">
                          {l.feature}
                        </text>
                      </g>
                    );
                  })}

                  {/* Draw PC1 Line (Emerald) */}
                  {(() => {
                    const count = pcaResult.loadings.length;
                    const pts = pcaResult.loadings.map((l, i) => ({
                      x: 50 + (i / Math.max(1, count - 1)) * 410,
                      y: 120 - l.pc1 * 130,
                    }));
                    const d = pts.reduce((acc, p, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`, '');
                    return (
                      <g>
                        <path d={d} fill="none" stroke="#10B981" strokeWidth="2" />
                        {pts.map((p, i) => (
                          <circle key={i} cx={p.x} cy={p.y} r="3" fill="#10B981" />
                        ))}
                      </g>
                    );
                  })()}

                  {/* Draw PC2 Line (Cyan) */}
                  {(() => {
                    const count = pcaResult.loadings.length;
                    const pts = pcaResult.loadings.map((l, i) => ({
                      x: 50 + (i / Math.max(1, count - 1)) * 410,
                      y: 120 - l.pc2 * 130,
                    }));
                    const d = pts.reduce((acc, p, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`, '');
                    return (
                      <g>
                        <path d={d} fill="none" stroke="#06B6D4" strokeWidth="2" />
                        {pts.map((p, i) => (
                          <circle key={i} cx={p.x} cy={p.y} r="3" fill="#06B6D4" />
                        ))}
                      </g>
                    );
                  })()}

                  {/* Draw PC3 Line (Purple) */}
                  {(() => {
                    const count = pcaResult.loadings.length;
                    const pts = pcaResult.loadings.map((l, i) => ({
                      x: 50 + (i / Math.max(1, count - 1)) * 410,
                      y: 120 - (l.pc3 || 0) * 130,
                    }));
                    const d = pts.reduce((acc, p, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`, '');
                    return (
                      <g>
                        <path d={d} fill="none" stroke="#A855F7" strokeWidth="2" strokeDasharray="4 2" />
                        {pts.map((p, i) => (
                          <circle key={i} cx={p.x} cy={p.y} r="3" fill="#A855F7" />
                        ))}
                      </g>
                    );
                  })()}
                </svg>
              </div>

              <div className="pt-2 border-t border-slate-800 text-[11px] font-mono text-slate-400">
                Notice how PC1, PC2, and PC3 isolate orthogonal nutrient dynamics (NPK vs Hydrology vs pH) across the dataset.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SECTION: 2D BIPLOT VIEW */}
      {/* ========================================================================= */}
      {(activeGraphTab === 'biplot' || activeGraphTab === 'dashboard') && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: 2D Biplot */}
          <div className="lg:col-span-2 p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Compass className="w-4 h-4 text-purple-400" />
                <h3 className="text-sm font-semibold text-white">
                  PCA Biplot Projection & Nutrient Vectors
                </h3>
                <span className="text-xs text-slate-400 font-mono">
                  ({xLabel}: {xVar}% &middot; {yLabel}: {yVar}%)
                </span>
              </div>

              {/* Projection Controls */}
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <div className="flex items-center bg-slate-950 p-1 rounded-lg border border-slate-800">
                  {(['pc1-pc2', 'pc1-pc3', 'pc2-pc3'] as const).map((pair) => (
                    <button
                      key={pair}
                      onClick={() => setActiveAxisPair(pair)}
                      className={`px-2 py-1 font-medium rounded uppercase transition-colors ${
                        activeAxisPair === pair
                          ? 'bg-slate-800 text-emerald-400 font-bold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {pair.replace('-', '/')}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => setShowVectors(!showVectors)}
                  className={`px-2.5 py-1 rounded-lg border font-mono transition-colors ${
                    showVectors
                      ? 'bg-purple-950/40 border-purple-500/50 text-purple-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  Vectors: {showVectors ? 'ON' : 'OFF'}
                </button>

                <select
                  value={selectedCropFilter}
                  onChange={(e) => setSelectedCropFilter(e.target.value)}
                  className="bg-slate-950 text-slate-200 border border-slate-800 rounded-lg px-2 py-1 text-xs font-mono"
                >
                  <option value="all">All Crops ({pcaResult.projectedData.length})</option>
                  {cropLabels.map((crop) => (
                    <option key={crop} value={crop}>
                      {crop.toUpperCase()}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* SVG Biplot Canvas */}
            <div className="relative w-full bg-slate-950 rounded-xl border border-slate-800/80 p-2 overflow-hidden">
              <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-auto max-h-[480px] select-none">
                {/* Coordinate Axes */}
                <line
                  x1={originX}
                  y1={padding}
                  x2={originX}
                  y2={svgHeight - padding}
                  stroke="#334155"
                  strokeWidth="1"
                  strokeDasharray="4 4"
                />
                <line
                  x1={padding}
                  y1={originY}
                  x2={svgWidth - padding}
                  y2={originY}
                  stroke="#334155"
                  strokeWidth="1"
                  strokeDasharray="4 4"
                />

                <text
                  x={svgWidth - padding - 10}
                  y={originY - 8}
                  fill="#94A3B8"
                  fontSize="11"
                  fontFamily="monospace"
                  fontWeight="bold"
                  textAnchor="end"
                >
                  {xLabel} ({xVar}%) &rarr;
                </text>
                <text
                  x={originX + 8}
                  y={padding + 14}
                  fill="#94A3B8"
                  fontSize="11"
                  fontFamily="monospace"
                  fontWeight="bold"
                >
                  &uarr; {yLabel} ({yVar}%)
                </text>

                {/* Directional Loading Vectors */}
                {showVectors &&
                  pcaResult.loadings.map((l) => {
                    let loadX = l.pc1;
                    let loadY = l.pc2;
                    if (activeAxisPair === 'pc1-pc3') {
                      loadX = l.pc1;
                      loadY = l.pc3;
                    } else if (activeAxisPair === 'pc2-pc3') {
                      loadX = l.pc2;
                      loadY = l.pc3;
                    }

                    const vecX = loadX * 4.5;
                    const vecY = loadY * 4.5;
                    const tipX = toSvgX(vecX);
                    const tipY = toSvgY(vecY);

                    return (
                      <g key={l.feature}>
                        <line
                          x1={originX}
                          y1={originY}
                          x2={tipX}
                          y2={tipY}
                          stroke="#F43F5E"
                          strokeWidth="1.8"
                          strokeLinecap="round"
                        />
                        <circle cx={tipX} cy={tipY} r="3" fill="#F43F5E" />
                        <text
                          x={tipX + (tipX > originX ? 6 : -6)}
                          y={tipY + (tipY > originY ? 4 : -4)}
                          fill="#FDA4AF"
                          fontSize="10"
                          fontFamily="monospace"
                          fontWeight="bold"
                          textAnchor={tipX > originX ? 'start' : 'end'}
                        >
                          {l.feature}
                        </text>
                      </g>
                    );
                  })}

                {/* Sample Data Points */}
                {visibleSamples.map((sample) => {
                  let sampleX = sample.pc1;
                  let sampleY = sample.pc2;
                  if (activeAxisPair === 'pc1-pc3') {
                    sampleX = sample.pc1;
                    sampleY = sample.pc3;
                  } else if (activeAxisPair === 'pc2-pc3') {
                    sampleX = sample.pc2;
                    sampleY = sample.pc3;
                  }

                  const cx = toSvgX(sampleX);
                  const cy = toSvgY(sampleY);
                  const profile = allProfiles[sample.label];
                  const color = profile ? profile.color : '#38BDF8';
                  const isHovered = hoveredPoint?.id === sample.id;

                  return (
                    <circle
                      key={sample.id}
                      cx={cx}
                      cy={cy}
                      r={isHovered ? 6 : 4}
                      fill={color}
                      opacity={isHovered ? 1 : 0.8}
                      stroke={isHovered ? '#FFFFFF' : '#0F172A'}
                      strokeWidth={isHovered ? 2 : 0.8}
                      className="cursor-pointer transition-all duration-100"
                      onMouseEnter={() => {
                        setHoveredPoint({
                          id: sample.id,
                          label: sample.label,
                          pcX: sampleX,
                          pcY: sampleY,
                          original: sample.original,
                        });
                      }}
                      onMouseLeave={() => setHoveredPoint(null)}
                    />
                  );
                })}
              </svg>

              {/* Hover Card */}
              {hoveredPoint && (
                <div className="absolute bottom-3 left-3 bg-slate-900/95 border border-slate-700 p-3 rounded-lg text-xs font-mono shadow-2xl backdrop-blur-md pointer-events-none z-20 space-y-1">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2.5 h-2.5 rounded-full"
                      style={{
                        backgroundColor: allProfiles[hoveredPoint.label]?.color || '#10B981',
                      }}
                    />
                    <span className="font-bold text-white uppercase">
                      {hoveredPoint.label} (Sample #{hoveredPoint.id})
                    </span>
                  </div>
                  <div className="text-slate-300">
                    {xLabel}: <span className="text-emerald-400 font-bold">{hoveredPoint.pcX}</span> &middot;{' '}
                    {yLabel}: <span className="text-emerald-400 font-bold">{hoveredPoint.pcY}</span>
                  </div>
                  {hoveredPoint.original && (
                    <div className="text-slate-400 text-[11px] pt-1 border-t border-slate-800 grid grid-cols-3 gap-x-3">
                      <span>N: {hoveredPoint.original.N}</span>
                      <span>P: {hoveredPoint.original.P}</span>
                      <span>K: {hoveredPoint.original.K}</span>
                      <span>pH: {hoveredPoint.original.ph?.toFixed(1)}</span>
                      <span>Rain: {Math.round(hoveredPoint.original.rainfall)}mm</span>
                      <span>Hum: {Math.round(hoveredPoint.original.humidity)}%</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Right: Loadings Matrix Table */}
          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h4 className="text-xs font-mono text-slate-300 uppercase">
                Loadings Matrix Table
              </h4>
              <span className="text-[10px] text-emerald-400 font-mono">
                {pcaResult.loadings.length} Features
              </span>
            </div>
            <div className="overflow-x-auto max-h-[400px]">
              <table className="w-full text-left text-xs font-mono tabular-nums">
                <thead className="sticky top-0 bg-slate-950 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-2 px-2">Feature</th>
                    <th className="py-2 px-2 text-emerald-400">PC1</th>
                    <th className="py-2 px-2 text-cyan-400">PC2</th>
                    <th className="py-2 px-2 text-purple-400">PC3</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {pcaResult.loadings.map((l) => (
                    <tr key={l.feature} className="hover:bg-slate-800/40">
                      <td className="py-1.5 px-2 font-medium">{l.feature}</td>
                      <td className="py-1.5 px-2">{l.pc1 > 0 ? `+${l.pc1}` : l.pc1}</td>
                      <td className="py-1.5 px-2">{l.pc2 > 0 ? `+${l.pc2}` : l.pc2}</td>
                      <td className="py-1.5 px-2">{l.pc3 > 0 ? `+${l.pc3}` : l.pc3}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
