import React, { useState } from 'react';
import { Layers, Activity, Info, Sparkles, Scale, Droplets, CheckSquare, Square, RotateCcw } from 'lucide-react';
import { CorrelationMatrix, EngineeredSoilSample } from '../types';
import { FeatureScalers, ALL_AVAILABLE_FEATURES, AvailableFeature } from '../services/featureEngineering';

interface FeatureEngineeringViewProps {
  samples: EngineeredSoilSample[];
  correlationMatrix: CorrelationMatrix;
  scalers: FeatureScalers;
  selectedFeatures: string[];
  setSelectedFeatures: (features: string[]) => void;
}

export const FeatureEngineeringView: React.FC<FeatureEngineeringViewProps> = ({
  samples,
  correlationMatrix,
  scalers,
  selectedFeatures,
  setSelectedFeatures,
}) => {
  const [hoveredCell, setHoveredCell] = useState<{
    f1: string;
    f2: string;
    val: number;
    i: number;
    j: number;
  } | null>(null);

  const getCorrColor = (val: number) => {
    if (val === 1) return 'bg-emerald-500/80 text-white font-bold';
    if (val > 0.6) return 'bg-emerald-600/70 text-emerald-100';
    if (val > 0.3) return 'bg-emerald-700/50 text-emerald-200';
    if (val > 0.05) return 'bg-emerald-950/40 text-emerald-300';
    if (val < -0.6) return 'bg-rose-600/70 text-rose-100';
    if (val < -0.3) return 'bg-rose-700/50 text-rose-200';
    if (val < -0.05) return 'bg-rose-950/40 text-rose-300';
    return 'bg-slate-900/60 text-slate-400';
  };

  const handleToggleFeature = (featId: string) => {
    if (selectedFeatures.includes(featId)) {
      if (selectedFeatures.length <= 3) {
        return; // require at least 3 features for PCA
      }
      setSelectedFeatures(selectedFeatures.filter(f => f !== featId));
    } else {
      setSelectedFeatures([...selectedFeatures, featId]);
    }
  };

  const handleSelectAbstractPreset = () => {
    // Exactly matches the user's abstract: "nitrogen, phosphorus, potassium, pH, moisture, and other nutrient-related parameters"
    setSelectedFeatures(['N', 'P', 'K', 'ph', 'moistureIndex', 'totalNPK', 'rainfall', 'humidity']);
  };

  const handleSelectAll = () => {
    setSelectedFeatures(ALL_AVAILABLE_FEATURES.map(f => f.id));
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="text-xs font-mono text-cyan-400 uppercase tracking-wider">Step 2 &middot; Abstract Requirement</div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-0.5">
            Feature Engineering, Transformation & Selection
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-3xl mt-1">
            &ldquo;Feature engineering is then applied to transform and select relevant soil attributes such as nitrogen, phosphorus,
            potassium, pH, moisture, and other nutrient-related parameters to obtain meaningful information from the dataset.&rdquo;
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleSelectAbstractPreset}
            className="px-3 py-1.5 text-xs font-medium text-cyan-300 bg-cyan-950/50 border border-cyan-800/60 rounded-lg hover:bg-cyan-900/50 transition-colors"
          >
            Abstract Target Preset
          </button>
          <button
            onClick={handleSelectAll}
            className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-800 rounded-lg hover:bg-slate-800 transition-colors"
          >
            Select All
          </button>
        </div>
      </div>

      {/* Interactive Feature Selection Panel */}
      <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <CheckSquare className="w-4 h-4 text-cyan-400" />
              Feature Selection for PCA Dimensionality Reduction
            </h3>
            <span className="text-xs text-slate-400">
              Select or deselect variables below; the PCA engine, Biplot, and ML models dynamically update.
            </span>
          </div>

          <span className="text-xs font-mono bg-slate-950 px-3 py-1 rounded border border-slate-800 text-slate-300">
            Selected: <strong className="text-emerald-400 font-bold">{selectedFeatures.length}</strong> / {ALL_AVAILABLE_FEATURES.length} features
          </span>
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {ALL_AVAILABLE_FEATURES.map(feat => {
            const isSelected = selectedFeatures.includes(feat.id);
            return (
              <div
                key={feat.id}
                onClick={() => handleToggleFeature(feat.id)}
                className={`p-3.5 rounded-xl border cursor-pointer transition-all duration-150 select-none space-y-2 flex flex-col justify-between ${
                  isSelected
                    ? 'bg-slate-950 border-cyan-500/50 shadow-sm'
                    : 'bg-slate-950/40 border-slate-800/60 opacity-60 hover:opacity-90'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono text-[10px] uppercase text-slate-400">{feat.category}</span>
                    <span className="font-mono text-[11px] text-cyan-400 font-bold">{feat.unit}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <div
                      className={`w-4 h-4 rounded flex items-center justify-center text-slate-950 ${
                        isSelected ? 'bg-cyan-400' : 'border border-slate-700 bg-slate-900'
                      }`}
                    >
                      {isSelected && <span className="text-xs font-bold leading-none">&#10003;</span>}
                    </div>
                    <span className="font-semibold text-sm text-white">{feat.name}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{feat.description}</p>
                </div>

                <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] font-mono text-slate-400">
                  <span>Mean:</span>
                  <span className="text-slate-200 font-semibold">{scalers.means[feat.id] ?? '—'}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Pearson Correlation Heatmap */}
      <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              Pearson Correlation Matrix (Heatmap)
            </h3>
            <span className="text-xs text-slate-400">
              Measures linear co-variation between soil parameters (-1.00 to +1.00). High correlation confirms suitability for PCA.
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-rose-400 font-bold">-1.0 (Inverse)</span>
            <div className="w-24 h-2.5 rounded bg-gradient-to-r from-rose-600 via-slate-800 to-emerald-500 border border-slate-700"></div>
            <span className="text-emerald-400 font-bold">+1.0 (Direct)</span>
          </div>
        </div>

        {/* Heatmap Grid */}
        <div className="overflow-x-auto">
          <div className="inline-block min-w-full">
            <table className="border-collapse text-[11px] font-mono">
              <thead>
                <tr>
                  <th className="p-1.5 text-left text-slate-400 font-normal">Feature</th>
                  {correlationMatrix.features.map(f => (
                    <th
                      key={f}
                      className="p-1.5 text-center text-slate-300 font-semibold"
                      style={{ minWidth: '46px' }}
                    >
                      <div className="truncate max-w-[50px]">{f}</div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {correlationMatrix.features.map((f1, i) => (
                  <tr key={f1} className="hover:bg-slate-800/30">
                    <td className="p-1.5 text-slate-300 font-medium whitespace-nowrap pr-3">
                      {f1}
                    </td>
                    {correlationMatrix.features.map((f2, j) => {
                      const val = correlationMatrix.matrix[i]?.[j] ?? 0;
                      const isHovered = hoveredCell?.i === i && hoveredCell?.j === j;
                      return (
                        <td
                          key={f2}
                          onMouseEnter={() => setHoveredCell({ f1, f2, val, i, j })}
                          onMouseLeave={() => setHoveredCell(null)}
                          className={`p-1.5 text-center transition-all cursor-crosshair rounded-xs ${getCorrColor(
                            val
                          )} ${isHovered ? 'ring-2 ring-white z-10 scale-110 shadow-lg' : ''}`}
                        >
                          {val === 1 ? '1.0' : val.toFixed(2)}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Tooltip bar */}
        <div className="h-10 flex items-center px-4 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono">
          {hoveredCell ? (
            <div className="flex items-center gap-4 text-slate-200">
              <span className="text-emerald-400 font-bold">
                r({hoveredCell.f1}, {hoveredCell.f2}) = {hoveredCell.val.toFixed(3)}
              </span>
              <span className="text-slate-400">&middot;</span>
              <span className="text-slate-300">
                {Math.abs(hoveredCell.val) > 0.7
                  ? 'High collinearity: Excellent candidate for PCA feature compression'
                  : Math.abs(hoveredCell.val) > 0.4
                  ? 'Moderate correlation'
                  : 'Independent orthogonal dimension'}
              </span>
            </div>
          ) : (
            <span className="text-slate-500">
              Hover over any cell in the correlation matrix to inspect the correlation coefficient r.
            </span>
          )}
        </div>
      </div>

      {/* Standardization Note */}
      <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 uppercase">
            <Scale className="w-3.5 h-3.5" />
            Standardization Mathematical Prerequisite
          </div>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            PCA projects axes in directions of maximum variance. If features are not standardized (Z = (x - &mu;) / &sigma;),
            variables with naturally large physical scales (like Rainfall: 20-300 mm) would artificially dominate variables with compact scales (like pH: 3.5-9.0),
            distorting the principal eigenvectors.
          </p>
        </div>
        <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs text-emerald-400 whitespace-nowrap">
          Z = (X - &mu;) / &sigma;
        </div>
      </div>
    </div>
  );
};
