import React, { useState, useMemo } from 'react';
import { Search, Filter, ArrowUpDown, Download, AlertTriangle, CheckCircle, Database, Upload } from 'lucide-react';
import { CleanedSoilSample, EngineeredSoilSample } from '../types';
import { CROP_PROFILES } from '../data/rawSoilData';

interface SoilDataTableProps {
  samples: EngineeredSoilSample[];
  onExportCSV: () => void;
  cropLabels: string[];
  datasetName?: string;
  onOpenDatasetManager?: () => void;
}

export const SoilDataTable: React.FC<SoilDataTableProps> = ({
  samples,
  onExportCSV,
  cropLabels,
  datasetName,
  onOpenDatasetManager,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCrop, setSelectedCrop] = useState('all');
  const [outlierOnly, setOutlierOnly] = useState(false);
  const [sortKey, setSortKey] = useState<string>('id');
  const [sortAsc, setSortAsc] = useState<boolean>(true);
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(20);

  // Sorting and Filtering
  const filteredSamples = useMemo(() => {
    return samples.filter(s => {
      if (selectedCrop !== 'all' && s.label !== selectedCrop) return false;
      if (outlierOnly && !s.isOutlier) return false;
      if (searchTerm) {
        const term = searchTerm.toLowerCase();
        const matchLabel = s.label.toLowerCase().includes(term);
        const matchId = s.id.toString().includes(term);
        if (!matchLabel && !matchId) return false;
      }
      return true;
    });
  }, [samples, selectedCrop, outlierOnly, searchTerm]);

  const sortedSamples = useMemo(() => {
    const list = [...filteredSamples];
    list.sort((a, b) => {
      const valA = (a as unknown as Record<string, any>)[sortKey];
      const valB = (b as unknown as Record<string, any>)[sortKey];
      if (typeof valA === 'number' && typeof valB === 'number') {
        return sortAsc ? valA - valB : valB - valA;
      }
      return sortAsc
        ? String(valA).localeCompare(String(valB))
        : String(valB).localeCompare(String(valA));
    });
    return list;
  }, [filteredSamples, sortKey, sortAsc]);

  const totalPages = Math.ceil(sortedSamples.length / pageSize) || 1;
  const paginatedSamples = useMemo(() => {
    const start = (page - 1) * pageSize;
    return sortedSamples.slice(start, start + pageSize);
  }, [sortedSamples, page, pageSize]);

  const handleSort = (key: string) => {
    if (sortKey === key) {
      setSortAsc(!sortAsc);
    } else {
      setSortKey(key);
      setSortAsc(true);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            Soil Samples Telemetry Table
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Showing {filteredSamples.length} of {samples.length} total samples
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {onOpenDatasetManager && (
            <button
              onClick={onOpenDatasetManager}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-300 bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-800/80 rounded-lg transition-colors whitespace-nowrap"
            >
              <Database className="w-3.5 h-3.5 text-emerald-400" />
              <span>Import / Switch Dataset</span>
            </button>
          )}
          <button
            onClick={onExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            Export Processed CSV
          </button>
        </div>
      </div>

      {/* Filter Ribbon */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 p-3 rounded-xl border border-slate-800 text-xs font-mono">
        <div className="flex flex-wrap items-center gap-3">
          {/* Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Search crop or ID..."
              value={searchTerm}
              onChange={e => {
                setSearchTerm(e.target.value);
                setPage(1);
              }}
              className="bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Crop Selector */}
          <select
            value={selectedCrop}
            onChange={e => {
              setSelectedCrop(e.target.value);
              setPage(1);
            }}
            className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="all">All Crops ({samples.length})</option>
            {cropLabels.map(crop => (
              <option key={crop} value={crop}>
                {crop.toUpperCase()}
              </option>
            ))}
          </select>

          {/* Outlier filter */}
          <label className="flex items-center gap-2 cursor-pointer text-slate-300 select-none">
            <input
              type="checkbox"
              checked={outlierOnly}
              onChange={e => {
                setOutlierOnly(e.target.checked);
                setPage(1);
              }}
              className="rounded border-slate-700 bg-slate-950 text-emerald-400 focus:ring-emerald-400"
            />
            <span>Show Anomalies Only</span>
          </label>
        </div>

        {/* Rows per page */}
        <div className="flex items-center gap-2 text-slate-400">
          <span>Rows:</span>
          {[15, 25, 50].map(sz => (
            <button
              key={sz}
              onClick={() => {
                setPageSize(sz);
                setPage(1);
              }}
              className={`px-2 py-0.5 rounded ${
                pageSize === sz
                  ? 'bg-slate-800 text-emerald-400 font-bold'
                  : 'hover:text-white'
              }`}
            >
              {sz}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900">
        <table className="w-full text-left text-xs font-mono tabular-nums">
          <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 select-none">
            <tr>
              {[
                { key: 'id', label: 'ID' },
                { key: 'label', label: 'Crop' },
                { key: 'N', label: 'N (kg/ha)' },
                { key: 'P', label: 'P (kg/ha)' },
                { key: 'K', label: 'K (kg/ha)' },
                { key: 'ph', label: 'pH' },
                { key: 'moistureIndex', label: 'Moisture Idx' },
                { key: 'temperature', label: 'Temp (°C)' },
                { key: 'humidity', label: 'Humidity (%)' },
                { key: 'rainfall', label: 'Rain (mm)' },
                { key: 'totalNPK', label: 'Total NPK' },
                { key: 'isOutlier', label: 'Quality' },
              ].map(col => (
                <th
                  key={col.key}
                  onClick={() => handleSort(col.key)}
                  className="py-3 px-3 font-semibold cursor-pointer hover:text-white transition-colors"
                >
                  <div className="flex items-center gap-1">
                    <span>{col.label}</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-600" />
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-slate-300">
            {paginatedSamples.length > 0 ? (
              paginatedSamples.map(sample => {
                const profile = CROP_PROFILES[sample.label];
                return (
                  <tr
                    key={sample.id}
                    className={`hover:bg-slate-800/40 transition-colors ${
                      sample.isOutlier ? 'bg-amber-950/10' : ''
                    }`}
                  >
                    <td className="py-2.5 px-3 text-slate-500 font-mono">#{sample.id}</td>
                    <td className="py-2.5 px-3 font-semibold text-white">
                      <div className="flex items-center gap-2">
                        <span
                          className="w-2 h-2 rounded-full shrink-0"
                          style={{ backgroundColor: profile?.color || '#10B981' }}
                        ></span>
                        <span className="capitalize">{sample.label}</span>
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-emerald-400">{sample.N}</td>
                    <td className="py-2.5 px-3 text-cyan-400">{sample.P}</td>
                    <td className="py-2.5 px-3 text-purple-400">{sample.K}</td>
                    <td className="py-2.5 px-3 text-slate-200">{sample.ph.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-cyan-300">{sample.moistureIndex.toFixed(1)}</td>
                    <td className="py-2.5 px-3">{sample.temperature.toFixed(1)}</td>
                    <td className="py-2.5 px-3">{sample.humidity.toFixed(1)}%</td>
                    <td className="py-2.5 px-3">{sample.rainfall.toFixed(1)}</td>
                    <td className="py-2.5 px-3 text-slate-400">{sample.totalNPK}</td>
                    <td className="py-2.5 px-3">
                      {sample.isOutlier ? (
                        <span className="text-amber-400 flex items-center gap-1 text-[11px]">
                          <AlertTriangle className="w-3 h-3" />
                          Outlier
                        </span>
                      ) : (
                        <span className="text-emerald-400 flex items-center gap-1 text-[11px]">
                          <CheckCircle className="w-3 h-3" />
                          Nominal
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={12} className="py-8 text-center text-slate-500 font-mono text-xs">
                  No matching soil samples found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono text-slate-400 px-1">
        <span>
          Page {page} of {totalPages} &middot; {sortedSamples.length} records matching filter
        </span>

        <div className="flex items-center gap-1">
          <button
            onClick={() => setPage(p => Math.max(1, p - 1))}
            disabled={page === 1}
            className="px-3 py-1 bg-slate-900 border border-slate-800 rounded hover:bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed text-slate-200"
          >
            Previous
          </button>
          <span className="px-2">{page}</span>
          <button
            onClick={() => setPage(p => Math.min(totalPages, p + 1))}
            disabled={page >= totalPages}
            className="px-3 py-1 bg-slate-900 border border-slate-800 rounded hover:bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed text-slate-200"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};
