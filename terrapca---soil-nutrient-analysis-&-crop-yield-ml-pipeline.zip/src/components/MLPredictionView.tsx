import React, { useState, useMemo } from 'react';
import {
  Award,
  Zap,
  Sliders,
  CheckCircle2,
  AlertCircle,
  ArrowUpRight,
  TrendingUp,
  Sparkles,
  Sprout,
  BarChart3,
  LineChart,
  Target,
  SlidersHorizontal,
  ChevronRight,
  HelpCircle,
} from 'lucide-react';
import {
  MLModelEvaluation,
  PCAResult,
  CropYieldPrediction,
  CropAgronomicProfile,
} from '../types';
import { CROP_PROFILES } from '../data/rawSoilData';
import { FeatureScalers } from '../services/featureEngineering';
import { predictCropYield } from '../services/mlModel';

interface MLPredictionViewProps {
  evaluation: MLModelEvaluation;
  pcaResult: PCAResult;
  scalers: FeatureScalers;
  featureNames: string[];
  cropProfiles?: Record<string, CropAgronomicProfile>;
}

export const MLPredictionView: React.FC<MLPredictionViewProps> = ({
  evaluation,
  pcaResult,
  scalers,
  featureNames,
  cropProfiles,
}) => {
  // Simulator Soil Inputs state
  const [soilInput, setSoilInput] = useState({
    N: 90,
    P: 42,
    K: 43,
    temperature: 24.5,
    humidity: 82.0,
    ph: 6.5,
    rainfall: 220.0,
  });

  // User Adjustable Reference Lines (Target Yield & Suitability Cutoff)
  const [targetYieldLine, setTargetYieldLine] = useState<number>(5.0); // in t/ha
  const [suitabilityThresholdLine, setSuitabilityThresholdLine] = useState<number>(65); // in %
  const [yieldGraphMode, setYieldGraphMode] = useState<'bar' | 'line'>('bar');
  const [activeCurveNutrient, setActiveCurveNutrient] = useState<'N' | 'P' | 'K'>('N');

  const soilPresets = [
    {
      name: 'Alluvial Wetland',
      cropHint: 'Paddy Rice',
      values: { N: 88, P: 48, K: 42, temperature: 23.5, humidity: 82.5, ph: 6.8, rainfall: 245 },
    },
    {
      name: 'Temperate Orchard',
      cropHint: 'Apple / Grape',
      values: { N: 24, P: 135, K: 200, temperature: 22.0, humidity: 92.0, ph: 6.0, rainfall: 110 },
    },
    {
      name: 'Semi-Arid Loam',
      cropHint: 'Chickpea / Mothbean',
      values: { N: 35, P: 68, K: 80, temperature: 19.5, humidity: 17.5, ph: 7.2, rainfall: 80 },
    },
    {
      name: 'Tropical Humid Coast',
      cropHint: 'Banana / Coconut',
      values: { N: 105, P: 82, K: 50, temperature: 27.5, humidity: 81.0, ph: 6.0, rainfall: 115 },
    },
    {
      name: 'Black Cotton Soil',
      cropHint: 'Cotton',
      values: { N: 120, P: 45, K: 20, temperature: 24.0, humidity: 80.0, ph: 7.2, rainfall: 82 },
    },
  ];

  // Run live prediction whenever slider inputs change
  const predictions: CropYieldPrediction[] = useMemo(() => {
    return predictCropYield(soilInput, featureNames, scalers, pcaResult, cropProfiles);
  }, [soilInput, featureNames, scalers, pcaResult, cropProfiles]);

  const allProfiles = cropProfiles || CROP_PROFILES;
  const topCrop = predictions[0];
  const topProfile = topCrop ? allProfiles[topCrop.crop] : null;

  // Crops meeting or exceeding the user-adjusted target yield line
  const qualifyingCropsCount = useMemo(() => {
    return predictions.filter((p) => p.expectedYieldTonsPerHa >= targetYieldLine).length;
  }, [predictions, targetYieldLine]);

  // Max yield in prediction set to scale graph
  const maxPredictionYield = useMemo(() => {
    const maxY = Math.max(...predictions.map((p) => p.expectedYieldTonsPerHa), targetYieldLine, 8);
    return Math.ceil(maxY + 1);
  }, [predictions, targetYieldLine]);

  // Generate Yield Response Curve points for active nutrient
  const responseCurvePoints = useMemo(() => {
    if (!topCrop || !topProfile) return [];
    const maxNutrientVal = activeCurveNutrient === 'K' ? 200 : activeCurveNutrient === 'P' ? 140 : 140;
    const baseYield = topCrop.expectedYieldTonsPerHa;
    const optimalRange =
      activeCurveNutrient === 'N'
        ? topProfile.optN
        : activeCurveNutrient === 'P'
        ? topProfile.optP
        : topProfile.optK;

    const optMid = (optimalRange[0] + optimalRange[1]) / 2;
    const points: { x: number; yieldVal: number }[] = [];

    for (let x = 0; x <= maxNutrientVal; x += maxNutrientVal / 20) {
      // Agronomic bell/plateau function
      const distance = Math.abs(x - optMid);
      const span = (optimalRange[1] - optimalRange[0]) * 1.5 || 30;
      const penaltyFactor = Math.min(1.0, (distance / span) ** 1.6);
      const y = Math.max(1.0, Number((baseYield * (1 - penaltyFactor * 0.55)).toFixed(2)));
      points.push({ x: Math.round(x), yieldVal: y });
    }
    return points;
  }, [topCrop, topProfile, activeCurveNutrient]);

  return (
    <div className="space-y-8">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="text-xs font-mono text-amber-400 uppercase tracking-wider">Phase 4 &middot; Decision Support</div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-0.5">
            ML Crop Classification & Yield Prediction Engine
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-3xl mt-1">
            Evaluate dimensionality reduction benchmarking, adjust yield target threshold lines, and simulate real-time soil chemistry responses across all crops in your active dataset.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-emerald-400 font-bold">
            PCA Accuracy: {evaluation.accuracyPCA}%
          </span>
        </div>
      </div>

      {/* Model Benchmark Card: Original vs PCA */}
      <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 space-y-5">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-semibold text-white">
              Dimensionality Reduction Benchmark: Full vs PCA Features
            </h3>
          </div>
          <span className="text-xs font-mono text-slate-400">
            K-Nearest Neighbors (k=5) &middot; 80/20 Stratified Split
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Full Dimensions Model */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex justify-between items-center text-xs font-mono text-slate-400">
              <span>Full Features Model</span>
              <span className="text-slate-300">{featureNames.length} Dimensions</span>
            </div>
            <div className="text-3xl font-mono font-bold text-white tabular-nums">
              {evaluation.accuracyOriginal}%
            </div>
            <p className="text-xs text-slate-400">
              Trained on raw standardized inputs. High accuracy but susceptible to collinearity between correlated nutrients.
            </p>
          </div>

          {/* PCA Model */}
          <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-2">
            <div className="flex justify-between items-center text-xs font-mono text-emerald-400">
              <span className="font-bold">PCA Reduced Model</span>
              <span className="font-bold">{pcaResult.kSelected} Components</span>
            </div>
            <div className="text-3xl font-mono font-bold text-emerald-400 tabular-nums">
              {evaluation.accuracyPCA}%
            </div>
            <p className="text-xs text-slate-300">
              Retains {pcaResult.cumulativeVariance[pcaResult.kSelected - 1] ?? 85}% of total variance with a {Math.round((1 - pcaResult.kSelected / Math.max(1, featureNames.length)) * 100)}% feature reduction. Zero multicollinearity.
            </p>
          </div>

          {/* Compression Efficiency */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="text-xs font-mono text-cyan-400">Dimensional Compression Efficiency</div>
            <div className="text-sm font-semibold text-slate-200">
              Preserved {(100 - Math.abs(evaluation.accuracyOriginal - evaluation.accuracyPCA)).toFixed(1)}% of Predictive Power
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              PCA compresses the multi-variable soil matrix into orthogonal axes with minimal loss in test classification accuracy.
            </p>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SECTION: ADJUSTABLE TARGET YIELD LINE & MULTI-CROP COMPARISON GRAPH */}
      {/* ========================================================================= */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2">
            <Target className="w-5 h-5 text-amber-400" />
            <div>
              <h3 className="text-base font-bold text-white">
                Interactive Crop Yield Graph with Adjustable Target Lines
              </h3>
              <p className="text-xs text-slate-400">
                Adjust the horizontal reference line to test farm yield quotas and minimum suitability standards for any active crop file.
              </p>
            </div>
          </div>

          {/* Mode Switcher */}
          <div className="flex items-center gap-3">
            <div className="flex items-center bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
              <button
                onClick={() => setYieldGraphMode('bar')}
                className={`flex items-center gap-1 px-3 py-1 rounded font-medium transition-all ${
                  yieldGraphMode === 'bar'
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5" />
                <span>Bar Graph</span>
              </button>
              <button
                onClick={() => setYieldGraphMode('line')}
                className={`flex items-center gap-1 px-3 py-1 rounded font-medium transition-all ${
                  yieldGraphMode === 'line'
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <LineChart className="w-3.5 h-3.5" />
                <span>Line Graph</span>
              </button>
            </div>
          </div>
        </div>

        {/* Adjustable Reference Lines Controls Toolbar */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 rounded-xl bg-slate-950/80 border border-slate-800">
          {/* 1. Target Yield Line Controller */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs font-mono">
              <span className="text-amber-300 font-semibold flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-amber-400 inline-block border-b border-dashed border-amber-400" />
                Adjustable Target Yield Line:
              </span>
              <span className="text-amber-400 font-bold text-sm bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/60">
                {targetYieldLine.toFixed(1)} t/ha
              </span>
            </div>

            <input
              type="range"
              min="1.0"
              max="12.0"
              step="0.2"
              value={targetYieldLine}
              onChange={(e) => setTargetYieldLine(parseFloat(e.target.value))}
              className="w-full accent-amber-400 h-2 bg-slate-900 rounded cursor-pointer"
            />

            <div className="flex flex-wrap gap-1.5 pt-1">
              {[
                { label: 'Low (3.0 t/ha)', val: 3.0 },
                { label: 'Standard (5.0 t/ha)', val: 5.0 },
                { label: 'High (7.5 t/ha)', val: 7.5 },
                { label: 'Max (10.0 t/ha)', val: 10.0 },
              ].map((b) => (
                <button
                  key={b.label}
                  onClick={() => setTargetYieldLine(b.val)}
                  className={`text-[10px] px-2 py-0.5 rounded border font-mono transition-colors ${
                    targetYieldLine === b.val
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 font-bold'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {b.label}
                </button>
              ))}
            </div>
          </div>

          {/* 2. Minimum Suitability Cutoff Line Controller */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs font-mono">
              <span className="text-cyan-300 font-semibold flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-cyan-400 inline-block border-b border-dashed border-cyan-400" />
                Suitability Cutoff Line:
              </span>
              <span className="text-cyan-400 font-bold text-sm bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/60">
                {suitabilityThresholdLine}%
              </span>
            </div>

            <input
              type="range"
              min="30"
              max="95"
              step="1"
              value={suitabilityThresholdLine}
              onChange={(e) => setSuitabilityThresholdLine(parseInt(e.target.value, 10))}
              className="w-full accent-cyan-400 h-2 bg-slate-900 rounded cursor-pointer"
            />

            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-1">
              <span>
                Qualifying Crops:{' '}
                <strong className="text-emerald-400">
                  {qualifyingCropsCount} of {predictions.length} crops
                </strong>{' '}
                meet or exceed your adjustable target line.
              </span>
            </div>
          </div>
        </div>

        {/* SVG Multi-Crop Yield Graph with the Adjustable Line */}
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 space-y-2 overflow-hidden">
          <div className="flex justify-between items-center text-xs font-mono text-slate-400 border-b border-slate-800 pb-2">
            <span>Crop Projected Yield vs Adjustable Line ({predictions.length} Crops in Dataset)</span>
            <span className="text-amber-400 font-bold">
              Target Line: {targetYieldLine.toFixed(1)} t/ha
            </span>
          </div>

          <div className="w-full overflow-x-auto">
            <svg
              viewBox={`0 0 ${Math.max(680, predictions.length * 45 + 80)} 260`}
              className="w-full h-auto min-w-[640px] select-none font-mono"
            >
              {/* Y Axis Grid Lines */}
              {[0, 2, 4, 6, 8, 10, 12].map((tick) => {
                if (tick > maxPredictionYield) return null;
                const y = 210 - (tick / maxPredictionYield) * 170;
                return (
                  <g key={tick}>
                    <line x1="50" y1={y} x2={Math.max(650, predictions.length * 45 + 50)} y2={y} stroke="#1E293B" strokeWidth="1" strokeDasharray="3 3" />
                    <text x="42" y={y + 3} fill="#64748B" fontSize="9" textAnchor="end">
                      {tick} t/ha
                    </text>
                  </g>
                );
              })}

              {/* ADJUSTABLE TARGET YIELD LINE (Amber/Gold Glowing Line) */}
              {(() => {
                const targetY = 210 - (targetYieldLine / maxPredictionYield) * 170;
                const rightX = Math.max(650, predictions.length * 45 + 50);

                return (
                  <g>
                    {/* Background glow line */}
                    <line
                      x1="50"
                      y1={targetY}
                      x2={rightX}
                      y2={targetY}
                      stroke="#F59E0B"
                      strokeWidth="3.5"
                      strokeDasharray="6 4"
                      opacity="0.3"
                    />
                    {/* Primary sharp dashed line */}
                    <line
                      x1="50"
                      y1={targetY}
                      x2={rightX}
                      y2={targetY}
                      stroke="#FBBF24"
                      strokeWidth="2"
                      strokeDasharray="6 4"
                    />
                    {/* Target Line Badge */}
                    <rect
                      x={rightX - 165}
                      y={targetY - 18}
                      width="160"
                      height="16"
                      rx="4"
                      fill="#78350F"
                      stroke="#F59E0B"
                      strokeWidth="1"
                    />
                    <text
                      x={rightX - 85}
                      y={targetY - 6}
                      fill="#FEF08A"
                      fontSize="9"
                      fontWeight="bold"
                      textAnchor="middle"
                    >
                      &uarr; Target Line: {targetYieldLine.toFixed(1)} t/ha
                    </text>
                  </g>
                );
              })()}

              {/* Render Crops as Bar Graph */}
              {yieldGraphMode === 'bar' &&
                predictions.map((p, i) => {
                  const x = 70 + i * 45;
                  const barH = (p.expectedYieldTonsPerHa / maxPredictionYield) * 170;
                  const y = 210 - barH;
                  const isQualifying = p.expectedYieldTonsPerHa >= targetYieldLine;
                  const profile = allProfiles[p.crop];
                  const color = profile ? profile.color : '#10B981';

                  return (
                    <g key={p.crop}>
                      {/* Bar */}
                      <rect
                        x={x - 12}
                        y={y}
                        width="24"
                        height={barH}
                        rx="3"
                        fill={color}
                        opacity={isQualifying ? 1 : 0.45}
                        stroke={isQualifying ? '#FFFFFF' : '#334155'}
                        strokeWidth={isQualifying ? 1.5 : 0.8}
                      />

                      {/* Yield Value on top of bar */}
                      <text
                        x={x}
                        y={y - 5}
                        fill={isQualifying ? '#34D399' : '#94A3B8'}
                        fontSize="9"
                        fontWeight="bold"
                        textAnchor="middle"
                      >
                        {p.expectedYieldTonsPerHa}
                      </text>

                      {/* Surplus / Deficit Indicator */}
                      <text
                        x={x}
                        y={y - 15}
                        fill={isQualifying ? '#10B981' : '#F43F5E'}
                        fontSize="8"
                        textAnchor="middle"
                      >
                        {p.expectedYieldTonsPerHa >= targetYieldLine
                          ? `+${(p.expectedYieldTonsPerHa - targetYieldLine).toFixed(1)}`
                          : `${(p.expectedYieldTonsPerHa - targetYieldLine).toFixed(1)}`}
                      </text>

                      {/* Crop Label under X-Axis */}
                      <text
                        x={x}
                        y="228"
                        fill={isQualifying ? '#FFFFFF' : '#64748B'}
                        fontSize="9"
                        textAnchor="middle"
                        className="capitalize"
                      >
                        {p.crop.slice(0, 5)}
                      </text>
                    </g>
                  );
                })}

              {/* Render Crops as Line Graph */}
              {yieldGraphMode === 'line' && (() => {
                const points = predictions.map((p, i) => ({
                  x: 70 + i * 45,
                  y: 210 - (p.expectedYieldTonsPerHa / maxPredictionYield) * 170,
                  crop: p.crop,
                  yieldVal: p.expectedYieldTonsPerHa,
                  isQualifying: p.expectedYieldTonsPerHa >= targetYieldLine,
                  color: allProfiles[p.crop]?.color || '#10B981',
                }));

                const d = points.reduce((acc, pt, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`, '');

                return (
                  <g>
                    <path d={d} fill="none" stroke="#10B981" strokeWidth="2.5" />
                    {points.map((pt, i) => (
                      <g key={pt.crop}>
                        <circle
                          cx={pt.x}
                          cy={pt.y}
                          r={pt.isQualifying ? 5 : 3.5}
                          fill={pt.isQualifying ? '#10B981' : '#EF4444'}
                          stroke="#0F172A"
                          strokeWidth="2"
                        />
                        <text
                          x={pt.x}
                          y={pt.y - 7}
                          fill={pt.isQualifying ? '#34D399' : '#F87171'}
                          fontSize="9"
                          fontWeight="bold"
                          textAnchor="middle"
                        >
                          {pt.yieldVal}
                        </text>
                        <text
                          x={pt.x}
                          y="228"
                          fill={pt.isQualifying ? '#FFFFFF' : '#64748B'}
                          fontSize="9"
                          textAnchor="middle"
                          className="capitalize"
                        >
                          {pt.crop.slice(0, 5)}
                        </text>
                      </g>
                    ))}
                  </g>
                );
              })()}
            </svg>
          </div>
        </div>

        {/* SECTION: YIELD RESPONSE CURVE (Line Graph with Vertical & Horizontal Lines) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-2">
          <div className="lg:col-span-8 bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
              <div className="text-xs font-mono text-slate-300 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <span>Nutrient Yield Response Curve for Top Crop:</span>
                <strong className="text-emerald-400 uppercase">{topCrop?.crop}</strong>
              </div>

              {/* Nutrient Curve Selector */}
              <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded border border-slate-800 text-[11px] font-mono">
                {(['N', 'P', 'K'] as const).map((nutr) => (
                  <button
                    key={nutr}
                    onClick={() => setActiveCurveNutrient(nutr)}
                    className={`px-2 py-0.5 rounded ${
                      activeCurveNutrient === nutr
                        ? 'bg-emerald-500 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {nutr} Response
                  </button>
                ))}
              </div>
            </div>

            {/* SVG Response Curve */}
            <div className="w-full overflow-hidden">
              <svg viewBox="0 0 520 200" className="w-full h-auto select-none font-mono">
                {/* Horizontal Target Yield Line */}
                {(() => {
                  const targetY = 160 - (targetYieldLine / maxPredictionYield) * 130;
                  return (
                    <g>
                      <line x1="50" y1={targetY} x2="480" y2={targetY} stroke="#F59E0B" strokeWidth="1.8" strokeDasharray="5 3" />
                      <text x="475" y={targetY - 4} fill="#FBBF24" fontSize="9" textAnchor="end">
                        Target Line ({targetYieldLine.toFixed(1)} t/ha)
                      </text>
                    </g>
                  );
                })()}

                {/* Vertical Current Input Line (Blue) */}
                {(() => {
                  const currentInputVal =
                    activeCurveNutrient === 'N'
                      ? soilInput.N
                      : activeCurveNutrient === 'P'
                      ? soilInput.P
                      : soilInput.K;
                  const maxVal = activeCurveNutrient === 'K' ? 200 : 140;
                  const currentX = 50 + (currentInputVal / maxVal) * 430;

                  return (
                    <g>
                      <line x1={currentX} y1="30" x2={currentX} y2="160" stroke="#38BDF8" strokeWidth="1.8" strokeDasharray="4 2" />
                      <text x={currentX} y="24" fill="#38BDF8" fontSize="9" fontWeight="bold" textAnchor="middle">
                        Current {activeCurveNutrient}: {currentInputVal}
                      </text>
                    </g>
                  );
                })()}

                {/* Response Polyline */}
                {(() => {
                  const maxVal = activeCurveNutrient === 'K' ? 200 : 140;
                  const pts = responseCurvePoints.map((pt) => ({
                    x: 50 + (pt.x / maxVal) * 430,
                    y: 160 - (pt.yieldVal / maxPredictionYield) * 130,
                    val: pt.yieldVal,
                  }));
                  const d = pts.reduce((acc, p, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`, '');

                  return (
                    <g>
                      <path d={d} fill="none" stroke="#10B981" strokeWidth="2.5" />
                      {pts.map((p, i) => (
                        <circle key={i} cx={p.x} cy={p.y} r="2.5" fill="#10B981" />
                      ))}
                    </g>
                  );
                })()}

                {/* X Axis */}
                <line x1="50" y1="160" x2="480" y2="160" stroke="#475569" strokeWidth="1" />
                <text x="50" y="175" fill="#64748B" fontSize="9">
                  0 kg/ha
                </text>
                <text x="265" y="175" fill="#94A3B8" fontSize="9" textAnchor="middle">
                  Soil {activeCurveNutrient} Application (kg/ha)
                </text>
                <text x="480" y="175" fill="#64748B" fontSize="9" textAnchor="end">
                  {activeCurveNutrient === 'K' ? '200' : '140'} kg/ha
                </text>
              </svg>
            </div>
          </div>

          {/* Quick Metrics Delta vs Target Line */}
          <div className="lg:col-span-4 bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3 flex flex-col justify-between text-xs">
            <div>
              <span className="font-mono text-slate-400 text-[11px] uppercase block">
                Target Line Compliance Status
              </span>
              <div className="mt-2 space-y-2">
                <div className="flex justify-between items-center p-2 rounded bg-slate-900 border border-slate-800">
                  <span className="text-slate-300">Top Crop Yield:</span>
                  <span className="font-mono text-emerald-400 font-bold text-sm">
                    {topCrop?.expectedYieldTonsPerHa} t/ha
                  </span>
                </div>
                <div className="flex justify-between items-center p-2 rounded bg-slate-900 border border-slate-800">
                  <span className="text-slate-300">Your Target Line:</span>
                  <span className="font-mono text-amber-400 font-bold text-sm">
                    {targetYieldLine.toFixed(1)} t/ha
                  </span>
                </div>
                <div className="flex justify-between items-center p-2 rounded bg-slate-900 border border-slate-800">
                  <span className="text-slate-300">Yield Margin:</span>
                  <span
                    className={`font-mono font-bold text-sm ${
                      (topCrop?.expectedYieldTonsPerHa || 0) >= targetYieldLine
                        ? 'text-emerald-400'
                        : 'text-rose-400'
                    }`}
                  >
                    {((topCrop?.expectedYieldTonsPerHa || 0) - targetYieldLine).toFixed(2)} t/ha
                  </span>
                </div>
              </div>
            </div>

            <div className="p-2.5 rounded bg-slate-900/60 border border-slate-800/80 text-[11px] text-slate-400">
              {(topCrop?.expectedYieldTonsPerHa || 0) >= targetYieldLine ? (
                <span className="text-emerald-400 flex items-center gap-1.5 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                  Expected yield comfortably satisfies your target quota.
                </span>
              ) : (
                <span className="text-amber-400 flex items-center gap-1.5 font-medium">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  Yield falls below target line. Apply recommended fertilizers below.
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SECTION: SOIL TESTING SIMULATOR & AGRONOMIC PRESCRIPTION */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sliders Input Column (5 cols) */}
        <div className="lg:col-span-5 p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-5">
          <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-semibold text-white">Soil & Climate Inputs</h3>
            </div>
            <span className="text-xs text-slate-500 font-mono">Live Lab</span>
          </div>

          {/* Presets */}
          <div className="space-y-1.5">
            <span className="text-xs text-slate-400 font-mono">SAMPLE REGIONAL PRESETS:</span>
            <div className="flex flex-wrap gap-1.5">
              {soilPresets.map((preset) => (
                <button
                  key={preset.name}
                  onClick={() => setSoilInput(preset.values)}
                  className="px-2.5 py-1 text-xs font-medium bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded-md transition-colors"
                >
                  {preset.name}
                </button>
              ))}
            </div>
          </div>

          {/* Individual Sliders */}
          <div className="space-y-4 pt-1">
            {/* Nitrogen */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-300 font-sans">Nitrogen (N)</span>
                <span className="text-emerald-400 font-bold">{soilInput.N} kg/ha</span>
              </div>
              <input
                type="range"
                min="0"
                max="140"
                step="1"
                value={soilInput.N}
                onChange={(e) => setSoilInput({ ...soilInput, N: parseInt(e.target.value, 10) })}
                className="w-full accent-emerald-400 h-1.5 bg-slate-950 rounded cursor-pointer"
              />
            </div>

            {/* Phosphorus */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-300 font-sans">Phosphorus (P)</span>
                <span className="text-cyan-400 font-bold">{soilInput.P} kg/ha</span>
              </div>
              <input
                type="range"
                min="5"
                max="145"
                step="1"
                value={soilInput.P}
                onChange={(e) => setSoilInput({ ...soilInput, P: parseInt(e.target.value, 10) })}
                className="w-full accent-cyan-400 h-1.5 bg-slate-950 rounded cursor-pointer"
              />
            </div>

            {/* Potassium */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-300 font-sans">Potassium (K)</span>
                <span className="text-purple-400 font-bold">{soilInput.K} kg/ha</span>
              </div>
              <input
                type="range"
                min="5"
                max="205"
                step="1"
                value={soilInput.K}
                onChange={(e) => setSoilInput({ ...soilInput, K: parseInt(e.target.value, 10) })}
                className="w-full accent-purple-400 h-1.5 bg-slate-950 rounded cursor-pointer"
              />
            </div>

            {/* pH */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-300 font-sans">Soil Reaction (pH)</span>
                <span className="text-amber-400 font-bold">
                  {soilInput.ph.toFixed(1)}{' '}
                  <span className="text-[10px] text-slate-500 font-normal">
                    ({soilInput.ph < 6 ? 'Acidic' : soilInput.ph > 7.5 ? 'Alkaline' : 'Neutral'})
                  </span>
                </span>
              </div>
              <input
                type="range"
                min="3.5"
                max="9.9"
                step="0.1"
                value={soilInput.ph}
                onChange={(e) => setSoilInput({ ...soilInput, ph: parseFloat(e.target.value) })}
                className="w-full accent-amber-400 h-1.5 bg-slate-950 rounded cursor-pointer"
              />
            </div>

            {/* Temperature */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-300 font-sans">Temperature</span>
                <span className="text-slate-200 font-bold">{soilInput.temperature.toFixed(1)} &deg;C</span>
              </div>
              <input
                type="range"
                min="8"
                max="45"
                step="0.5"
                value={soilInput.temperature}
                onChange={(e) =>
                  setSoilInput({ ...soilInput, temperature: parseFloat(e.target.value) })
                }
                className="w-full accent-slate-400 h-1.5 bg-slate-950 rounded cursor-pointer"
              />
            </div>

            {/* Humidity */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-300 font-sans">Relative Humidity</span>
                <span className="text-slate-200 font-bold">{soilInput.humidity.toFixed(0)} %</span>
              </div>
              <input
                type="range"
                min="14"
                max="100"
                step="1"
                value={soilInput.humidity}
                onChange={(e) =>
                  setSoilInput({ ...soilInput, humidity: parseFloat(e.target.value) })
                }
                className="w-full accent-slate-400 h-1.5 bg-slate-950 rounded cursor-pointer"
              />
            </div>

            {/* Rainfall */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-300 font-sans">Rainfall</span>
                <span className="text-cyan-400 font-bold">{soilInput.rainfall.toFixed(0)} mm</span>
              </div>
              <input
                type="range"
                min="20"
                max="300"
                step="1"
                value={soilInput.rainfall}
                onChange={(e) =>
                  setSoilInput({ ...soilInput, rainfall: parseFloat(e.target.value) })
                }
                className="w-full accent-cyan-400 h-1.5 bg-slate-950 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Prediction Results & Agronomic Advice (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Primary Recommendation Card */}
          {topCrop && topProfile && (
            <div className="p-6 rounded-2xl bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/40 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  Primary Crop Recommendation
                </span>
                <div className="px-2.5 py-1 rounded bg-emerald-400 text-slate-950 text-xs font-bold font-mono">
                  {topCrop.suitabilityScore}% Suitability
                </div>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
                <div>
                  <h3 className="text-2xl sm:text-3xl font-extrabold text-white">
                    {topProfile.displayName}
                  </h3>
                  <span className="text-xs text-slate-400 font-mono">
                    Category: {topProfile.category}
                  </span>
                </div>

                <div className="sm:text-right">
                  <div className="text-xs font-mono text-slate-400 uppercase">Estimated Yield</div>
                  <div className="text-2xl sm:text-3xl font-mono font-bold text-emerald-400 tabular-nums">
                    {topCrop.expectedYieldTonsPerHa}{' '}
                    <span className="text-xs font-sans font-normal text-slate-300">t / ha</span>
                  </div>
                  <div className="text-[11px] text-slate-500 font-mono">
                    Range: {topCrop.typicalYieldRange[0]} &ndash; {topCrop.typicalYieldRange[1]} t/ha
                  </div>
                </div>
              </div>

              {/* PCA Coordinates of this custom sample */}
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono flex items-center justify-between text-slate-300">
                <span>Transformed PCA Projection:</span>
                <span className="text-cyan-400 font-bold">
                  PC1 = {topCrop.pcaCoordinates.pc1} &middot; PC2 = {topCrop.pcaCoordinates.pc2} &middot; PC3 = {topCrop.pcaCoordinates.pc3}
                </span>
              </div>

              {/* Agronomic Recommendations & Fertilizer Prescription */}
              <div className="space-y-2 pt-2 border-t border-slate-800/80">
                <h4 className="text-xs font-mono uppercase tracking-wider text-slate-300">
                  Fertilizer Prescription & Agronomic Guidance
                </h4>
                {topCrop.amendments.length > 0 ? (
                  <div className="space-y-1.5">
                    {topCrop.amendments.map((amendment, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-2 text-xs text-slate-300 bg-slate-950/60 p-2 rounded border border-slate-800/60"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{amendment}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-xs text-emerald-400 bg-emerald-950/20 p-2.5 rounded border border-emerald-500/20 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    Soil conditions are balanced within optimal physiological thresholds for {topProfile.displayName}.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Alternative Crops Ranked */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400">
              Ranked Alternative Crops & Suitability
            </h4>

            <div className="space-y-2">
              {predictions.slice(1, 6).map((pred) => {
                const profile = allProfiles[pred.crop];
                if (!profile) return null;
                const isOverTarget = pred.expectedYieldTonsPerHa >= targetYieldLine;

                return (
                  <div
                    key={pred.crop}
                    className="p-3 rounded-lg bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2.5">
                      <span
                        className="w-2.5 h-2.5 rounded-full"
                        style={{ backgroundColor: profile.color }}
                      />
                      <div>
                        <span className="font-semibold text-white">{profile.displayName}</span>
                        <span className="text-slate-500 ml-2 font-mono text-[11px]">
                          ({profile.category})
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 font-mono">
                      <span
                        className={isOverTarget ? 'text-emerald-400 font-bold' : 'text-slate-300'}
                      >
                        {pred.expectedYieldTonsPerHa} t/ha
                      </span>
                      <div className="w-16 h-2 bg-slate-800 rounded-full overflow-hidden flex">
                        <div
                          className="h-full bg-emerald-400"
                          style={{ width: `${pred.suitabilityScore}%` }}
                        />
                      </div>
                      <span className="text-emerald-400 font-bold w-9 text-right">
                        {pred.suitabilityScore}%
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
