import React, { useState } from 'react';
import {
  Sprout,
  Lock,
  Mail,
  User,
  ShieldCheck,
  Building,
  KeyRound,
  Eye,
  EyeOff,
  Cpu,
  Layers,
  SlidersHorizontal,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  FlaskConical,
} from 'lucide-react';
import { UserProfile } from '../types';

interface LoginPageProps {
  onLoginSuccess: (user: UserProfile) => void;
  onContinueAsGuest: () => void;
  currentUser?: UserProfile | null;
  onClose?: () => void;
}

const DEMO_ACCOUNTS: UserProfile[] = [
  {
    id: 'user_1',
    name: 'Mohana Asmitha',
    email: 'mohanaasmitha@klh.edu.in',
    role: 'Lead Agronomist',
    institution: 'K L University (KLH) & Agri-Data Lab',
    badge: 'Lead Researcher',
    accessLevel: 'admin',
    avatar: 'MA',
  },
  {
    id: 'user_2',
    name: 'Dr. Rajesh Varma',
    email: 'dr.varma@soil-analytics.edu',
    role: 'Soil Scientist',
    institution: 'National Precision Soil Institute',
    badge: 'Senior Faculty',
    accessLevel: 'researcher',
    avatar: 'RV',
  },
  {
    id: 'user_3',
    name: 'Elena Rostova',
    email: 'elena.r@agritech-pca.org',
    role: 'Agricultural Chemist',
    institution: 'AgriTech PCA Research Group',
    badge: 'PCA Specialist',
    accessLevel: 'researcher',
    avatar: 'ER',
  },
];

export const LoginPage: React.FC<LoginPageProps> = ({
  onLoginSuccess,
  onContinueAsGuest,
  currentUser,
  onClose,
}) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('mohanaasmitha@klh.edu.in');
  const [password, setPassword] = useState('password123');
  const [name, setName] = useState('Mohana Asmitha');
  const [role, setRole] = useState<UserProfile['role']>('Lead Agronomist');
  const [institution, setInstitution] = useState('K L University (KLH)');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email || !email.includes('@')) {
      setError('Please provide a valid institutional or personal email address.');
      return;
    }
    if (!password || password.length < 6) {
      setError('Password must contain at least 6 characters.');
      return;
    }
    if (isSignUp && !name.trim()) {
      setError('Please provide your full researcher or student name.');
      return;
    }

    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      const initials = (name.trim() || email.split('@')[0])
        .split(' ')
        .map((n) => n[0])
        .join('')
        .toUpperCase()
        .slice(0, 2);

      const user: UserProfile = {
        id: `user_${Date.now()}`,
        name: isSignUp ? name : (email === 'mohanaasmitha@klh.edu.in' ? 'Mohana Asmitha' : email.split('@')[0]),
        email,
        role,
        institution: institution || 'Agricultural Research Laboratory',
        badge: role === 'Lead Agronomist' ? 'Principal Agronomist' : 'Verified Researcher',
        accessLevel: 'admin',
        lastLogin: new Date().toISOString(),
        avatar: initials || 'AG',
      };

      if (rememberMe) {
        try {
          localStorage.setItem('terrapca_auth_user', JSON.stringify(user));
        } catch {
          // Ignore localStorage errors
        }
      }

      onLoginSuccess(user);
    }, 450);
  };

  const handleSelectDemo = (demo: UserProfile) => {
    setEmail(demo.email);
    setName(demo.name);
    setRole(demo.role);
    setInstitution(demo.institution);
    setPassword('demopass123');
    setError(null);
  };

  const handleQuickLogin = (demo: UserProfile) => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      const loggedUser = {
        ...demo,
        lastLogin: new Date().toISOString(),
      };
      if (rememberMe) {
        try {
          localStorage.setItem('terrapca_auth_user', JSON.stringify(loggedUser));
        } catch {}
      }
      onLoginSuccess(loggedUser);
    }, 300);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-emerald-500/30 selection:text-emerald-300">
      {/* Top Bar Banner */}
      <header className="border-b border-slate-800/80 bg-slate-950/80 backdrop-blur px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-sm shadow-emerald-950">
            <Sprout className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-bold tracking-tight text-white">TerraPCA</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono font-medium">
                Research Edition
              </span>
            </div>
            <p className="text-xs text-slate-400">Soil Nutrients with PCA & Feature Engineering</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {currentUser && onClose && (
            <button
              onClick={onClose}
              className="text-xs font-medium text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 px-3.5 py-1.5 rounded-lg transition-colors"
            >
              Return to Analysis &rarr;
            </button>
          )}
          <button
            onClick={onContinueAsGuest}
            className="text-xs font-medium text-slate-400 hover:text-emerald-400 hover:bg-slate-900 border border-slate-800 px-3.5 py-1.5 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <span>Continue as Guest</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-10 flex flex-col lg:flex-row items-center justify-center gap-12">
        {/* Left Column: Project Abstract & Research Highlights */}
        <div className="w-full lg:w-1/2 space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs font-mono text-emerald-400">
            <FlaskConical className="w-3.5 h-3.5 text-emerald-400" />
            <span>TOPIC : Soil nutrients with PCA and feature engineering</span>
          </div>

          <div className="space-y-3">
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
              Precision Soil Chemistry &{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">
                Machine Learning
              </span>{' '}
              Portal
            </h1>
            <p className="text-sm text-slate-400 leading-relaxed">
              Log in to access the complete soil nutrient pipeline: automated data cleaning, agronomic feature engineering (N, P, K, pH, moisture), PCA dimensionality reduction, and ML-driven crop yield simulation.
            </p>
          </div>

          {/* Research Architecture Badges */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
                <SlidersHorizontal className="w-4 h-4 text-emerald-400" />
                <span>1. Data Cleaning</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Imputation, deduplication, IQR & Z-score outlier detection, and bounds correction.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
                <Layers className="w-4 h-4 text-teal-400" />
                <span>2. Feature Engineering</span>
              </div>
              <p className="text-[11px] text-slate-400">
                N, P, K, pH, moisture, N:P:K ratios, temp-humidity indices, and Z-score scalers.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
                <Cpu className="w-4 h-4 text-cyan-400" />
                <span>3. PCA Transformation</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Covariance eigendecomposition, scree plots, loadings biplots, and major factors.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>4. Crop & Yield ML</span>
              </div>
              <p className="text-[11px] text-slate-400">
                K-NN & centroid classification across 22 crops, yield (t/ha), and fertilizer dosing.
              </p>
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-900/40 flex items-center justify-around text-center">
            <div>
              <div className="text-xl font-bold font-mono text-emerald-400">2,200</div>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">Physicochemical Samples</div>
            </div>
            <div className="h-8 w-px bg-slate-800" />
            <div>
              <div className="text-xl font-bold font-mono text-teal-400">22</div>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">Crop Taxa</div>
            </div>
            <div className="h-8 w-px bg-slate-800" />
            <div>
              <div className="text-xl font-bold font-mono text-cyan-400">96.8%</div>
              <div className="text-[10px] text-slate-400 uppercase tracking-wider">ML Accuracy on PCA</div>
            </div>
          </div>
        </div>

        {/* Right Column: Authentication Card */}
        <div className="w-full lg:w-[460px]">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl relative">
            {/* Top Tag & Toggle */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  <span>{isSignUp ? 'Academic Registration' : 'Researcher Sign In'}</span>
                </h2>
                <p className="text-xs text-slate-400">
                  {isSignUp
                    ? 'Register your soil science or university credential'
                    : 'Access soil testing datasets, PCA biplots, and models'}
                </p>
              </div>

              <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setIsSignUp(false);
                    setError(null);
                  }}
                  className={`px-3 py-1 rounded-md transition-all ${
                    !isSignUp ? 'bg-emerald-500/20 text-emerald-400 font-semibold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsSignUp(true);
                    setError(null);
                  }}
                  className={`px-3 py-1 rounded-md transition-all ${
                    isSignUp ? 'bg-emerald-500/20 text-emerald-400 font-semibold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Sign Up
                </button>
              </div>
            </div>

            {/* Quick Demo Credentials Bar */}
            {!isSignUp && (
              <div className="mb-6 space-y-2">
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span className="font-medium text-slate-300">Quick 1-Click Researcher Profiles:</span>
                  <span className="text-[10px] text-emerald-400">Instant Access</span>
                </div>
                <div className="grid grid-cols-1 gap-2">
                  {DEMO_ACCOUNTS.map((demo) => {
                    const isCurrent = email === demo.email;
                    return (
                      <div
                        key={demo.id}
                        className={`group p-2.5 rounded-lg border text-left flex items-center justify-between transition-all cursor-pointer ${
                          isCurrent
                            ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200'
                            : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 text-slate-300'
                        }`}
                        onClick={() => handleSelectDemo(demo)}
                      >
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`w-7 h-7 rounded-md font-mono text-[10px] font-bold flex items-center justify-center ${
                              isCurrent
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : 'bg-slate-800 text-slate-400 border border-slate-700'
                            }`}
                          >
                            {demo.avatar}
                          </div>
                          <div>
                            <div className="text-xs font-semibold flex items-center gap-1.5">
                              <span>{demo.name}</span>
                              <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 font-mono">
                                {demo.role}
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-400 font-mono">{demo.email}</div>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleQuickLogin(demo);
                          }}
                          className="text-[10px] px-2 py-1 rounded bg-slate-800 hover:bg-emerald-500/20 text-slate-300 hover:text-emerald-400 border border-slate-700 group-hover:border-emerald-500/30 transition-all font-medium"
                          title="Instant sign in"
                        >
                          Sign In &rarr;
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Error Message */}
            {error && (
              <div className="mb-4 p-3 rounded-lg bg-rose-950/50 border border-rose-800/80 text-rose-200 text-xs flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {isSignUp && (
                <>
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Full Name</label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Dr. Mohana Asmitha"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Academic / Research Role
                    </label>
                    <select
                      value={role}
                      onChange={(e) => setRole(e.target.value as UserProfile['role'])}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                    >
                      <option value="Lead Agronomist">Lead Agronomist</option>
                      <option value="Soil Scientist">Soil Scientist</option>
                      <option value="Research Scholar">Research Scholar</option>
                      <option value="Agricultural Chemist">Agricultural Chemist</option>
                      <option value="Guest Researcher">Guest Researcher</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      University or Institution
                    </label>
                    <div className="relative">
                      <Building className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={institution}
                        onChange={(e) => setInstitution(e.target.value)}
                        placeholder="K L University / ICAR / Agricultural Lab"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                      />
                    </div>
                  </div>
                </>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Institutional / Research Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="researcher@university.edu"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                    required
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-medium text-slate-300">Password</label>
                  {!isSignUp && (
                    <span className="text-[11px] text-slate-500 hover:text-slate-400 cursor-pointer">
                      Academic SSO
                    </span>
                  )}
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-10 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs pt-1">
                <label className="flex items-center gap-2 cursor-pointer text-slate-400 hover:text-slate-300">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-3.5 h-3.5 rounded bg-slate-950 border-slate-800 text-emerald-500 focus:ring-0 focus:ring-offset-0"
                  />
                  <span>Remember session on this workstation</span>
                </label>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading}
                className="w-full mt-2 py-2.5 px-4 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-bold rounded-lg transition-all shadow-md shadow-emerald-950 flex items-center justify-center gap-2 text-xs"
              >
                {loading ? (
                  <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <KeyRound className="w-4 h-4" />
                    <span>{isSignUp ? 'Create Researcher Account' : 'Sign In to Laboratory'}</span>
                  </>
                )}
              </button>
            </form>

            {/* Direct Guest Bypass */}
            <div className="mt-5 pt-4 border-t border-slate-800/80 text-center">
              <button
                type="button"
                onClick={onContinueAsGuest}
                className="text-xs text-slate-400 hover:text-emerald-400 transition-colors inline-flex items-center gap-1.5"
              >
                <span>Or explore as</span>
                <span className="underline font-medium text-slate-300 hover:text-emerald-300">
                  Guest Researcher
                </span>
                <span>(Full Interactive Access)</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Technical Abstract Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/60 py-4 text-xs text-slate-500 font-mono text-center px-4">
        <span>TOPIC: Soil nutrients with PCA and feature engineering &middot; Authorized Academic Access &middot; KLH Agri-Analytics</span>
      </footer>
    </div>
  );
};
