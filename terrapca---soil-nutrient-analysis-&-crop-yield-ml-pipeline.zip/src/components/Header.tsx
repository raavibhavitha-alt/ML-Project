import React, { useState, useRef, useEffect } from 'react';
import {
  Sprout,
  RefreshCw,
  Download,
  SlidersHorizontal,
  Table,
  Cpu,
  Layers,
  FileText,
  LogIn,
  LogOut,
  UserCheck,
  ChevronDown,
  Building,
  Shield,
  Database,
  Upload,
} from 'lucide-react';
import { UserProfile, DatasetInfo } from '../types';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onResetData: () => void;
  onExportCSV: () => void;
  totalSamples: number;
  currentUser: UserProfile | null;
  onOpenLogin: () => void;
  onLogout: () => void;
  currentDataset: DatasetInfo;
  onOpenDatasetManager: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onResetData,
  onExportCSV,
  totalSamples,
  currentUser,
  onOpenLogin,
  onLogout,
  currentDataset,
  onOpenDatasetManager,
}) => {
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const navItems = [
    { id: 'overview', label: 'Abstract & Scope', icon: Sprout },
    { id: 'cleaning', label: '1. Data Cleaning', icon: SlidersHorizontal },
    { id: 'features', label: '2. Feature Engineering', icon: Layers },
    { id: 'pca', label: '3. PCA & Major Factors', icon: Cpu },
    { id: 'prediction', label: '4. ML & Yield Predictor', icon: Sprout },
    { id: 'report', label: 'Project Report', icon: FileText },
    { id: 'dataset', label: 'Data Explorer', icon: Table },
  ];

  // Close menu on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-40 w-full bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-3">
        {/* Brand identity */}
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('overview')}>
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Sprout className="w-5 h-5" />
          </div>
          <div>
            <span className="text-lg font-bold tracking-tight text-white flex items-center gap-1.5">
              TerraPCA
            </span>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden xl:flex items-center gap-1">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  isActive
                    ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Primary actions & User Auth */}
        <div className="flex items-center gap-2">
          <button
            onClick={onResetData}
            title="Reset dataset and parameters"
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors whitespace-nowrap"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Reset</span>
          </button>

          <button
            onClick={onExportCSV}
            title="Export processed dataset"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors shadow-sm whitespace-nowrap font-semibold"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>

          {/* Dataset Ingestion / Switcher Pill */}
          <button
            onClick={onOpenDatasetManager}
            title="Upload custom dataset or switch crop files"
            className="flex items-center gap-2 px-2.5 py-1.5 text-xs font-medium text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-800/60 rounded-lg transition-colors whitespace-nowrap shadow-sm"
          >
            <Database className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
            <div className="flex items-center gap-1.5 text-left">
              <span className="hidden sm:inline font-mono font-semibold max-w-[130px] truncate text-[11px]">
                {currentDataset.name.split('(')[0].trim()}
              </span>
              <span className="sm:hidden font-mono text-[11px]">Dataset</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-900/60 text-emerald-300 font-mono hidden md:inline">
                {currentDataset.sampleCount} rows
              </span>
            </div>
            <Upload className="w-3 h-3 text-emerald-400/80 ml-0.5" />
          </button>

          {/* User Account / Profile Menu */}
          <div className="relative" ref={menuRef}>
            {currentUser ? (
              <button
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all text-left"
              >
                <div className="w-6 h-6 rounded-md bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-mono text-[10px] font-bold flex items-center justify-center">
                  {currentUser.avatar || currentUser.name.slice(0, 2).toUpperCase()}
                </div>
                <div className="hidden md:block">
                  <div className="text-xs font-medium text-slate-200 leading-tight">
                    {currentUser.name}
                  </div>
                  <div className="text-[10px] text-emerald-400 font-mono leading-none">
                    {currentUser.role}
                  </div>
                </div>
                <ChevronDown className="w-3 h-3 text-slate-400 ml-0.5" />
              </button>
            ) : (
              <button
                onClick={onOpenLogin}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-400 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 rounded-lg transition-colors whitespace-nowrap"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In</span>
              </button>
            )}

            {/* Dropdown Menu */}
            {userMenuOpen && currentUser && (
              <div className="absolute right-0 mt-2 w-64 rounded-xl bg-slate-900 border border-slate-800 shadow-2xl p-3 z-50 text-xs">
                <div className="pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2 mb-1.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-mono text-xs font-bold flex items-center justify-center">
                      {currentUser.avatar || currentUser.name.slice(0, 2).toUpperCase()}
                    </div>
                    <div className="overflow-hidden">
                      <div className="font-semibold text-white truncate">{currentUser.name}</div>
                      <div className="text-[11px] text-slate-400 font-mono truncate">{currentUser.email}</div>
                    </div>
                  </div>

                  <div className="mt-2 space-y-1">
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-300">
                      <Shield className="w-3 h-3 text-emerald-400" />
                      <span>Role: <strong className="text-emerald-400 font-normal">{currentUser.role}</strong></span>
                    </div>
                    {currentUser.institution && (
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                        <Building className="w-3 h-3 text-slate-500" />
                        <span className="truncate">{currentUser.institution}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-2 space-y-1">
                  <button
                    onClick={() => {
                      setUserMenuOpen(false);
                      onOpenLogin();
                    }}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors flex items-center gap-2"
                  >
                    <UserCheck className="w-3.5 h-3.5 text-slate-400" />
                    <span>Switch Researcher Profile</span>
                  </button>

                  <button
                    onClick={() => {
                      setUserMenuOpen(false);
                      onLogout();
                    }}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 transition-colors flex items-center gap-2"
                  >
                    <LogOut className="w-3.5 h-3.5 text-rose-400" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Sub-navigation for medium and small screens */}
      <div className="xl:hidden flex overflow-x-auto px-4 py-2 border-t border-slate-800/60 gap-1 bg-slate-950">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`px-3 py-1 text-xs font-medium rounded-md whitespace-nowrap ${
                isActive
                  ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </div>
    </header>
  );
};
