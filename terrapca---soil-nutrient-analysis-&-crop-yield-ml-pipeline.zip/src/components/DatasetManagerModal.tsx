import React, { useState, useRef } from 'react';
import {
  Upload,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  X,
  Layers,
  Sparkles,
  ArrowRight,
  Database,
  Sprout,
  HelpCircle,
  FileText,
  RefreshCw,
} from 'lucide-react';
import { ColumnMapping, DatasetInfo, RawSoilSample } from '../types';
import { BENCHMARK_DATASETS } from '../data/benchmarkDatasets';
import {
  parseUniversalCSV,
  smartAutoMap,
  UniversalParseResult,
} from '../services/universalDatasetParser';

interface DatasetManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDatasetLoaded: (
    dataset: DatasetInfo,
    samples: RawSoilSample[],
    mapping: ColumnMapping
  ) => void;
  currentDataset: DatasetInfo;
}

export const DatasetManagerModal: React.FC<DatasetManagerModalProps> = ({
  isOpen,
  onClose,
  onDatasetLoaded,
  currentDataset,
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'benchmarks'>('upload');
  const [csvInput, setCsvInput] = useState<string>('');
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const [parseResult, setParseResult] = useState<UniversalParseResult | null>(null);
  const [userMapping, setUserMapping] = useState<ColumnMapping>({
    N: '',
    P: '',
    K: '',
    temperature: '',
    humidity: '',
    ph: '',
    rainfall: '',
    label: '',
  });
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleProcessText = (text: string, fileName?: string) => {
    setCsvInput(text);
    if (fileName) setUploadedFileName(fileName);
    const res = parseUniversalCSV(text);
    setParseResult(res);
    setUserMapping(res.mapping);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      handleProcessText(content, file.name);
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    const file = e.dataTransfer.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      handleProcessText(content, file.name);
    };
    reader.readAsText(file);
  };

  const handleLoadCustom = () => {
    if (!parseResult) return;
    const reParsed = parseUniversalCSV(csvInput, userMapping);
    const uniqueCrops = Array.from(new Set(reParsed.samples.map((s) => s.label))).sort();

    const info: DatasetInfo = {
      id: `custom_${Date.now()}`,
      name: uploadedFileName || 'Custom Crop Dataset',
      description: `User-imported soil nutrient file with ${reParsed.samples.length} rows across ${uniqueCrops.length} crop categories.`,
      category: 'Custom Upload',
      sampleCount: reParsed.samples.length,
      cropCount: uniqueCrops.length,
      crops: uniqueCrops,
      rawText: csvInput,
      uploadedAt: new Date().toLocaleTimeString(),
    };

    onDatasetLoaded(info, reParsed.samples, userMapping);
    onClose();
  };

  const handleSelectBenchmark = (bench: DatasetInfo) => {
    const res = parseUniversalCSV(bench.rawText || '');
    onDatasetLoaded(bench, res.samples, res.mapping);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">Universal Dataset & Crop File Ingestion</h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono">
                  Any Dataset Supported
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Current Active: <strong className="text-emerald-400 font-mono">{currentDataset.name}</strong> ({currentDataset.sampleCount} rows, {currentDataset.cropCount} crops)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="px-6 pt-3 border-b border-slate-800 flex items-center gap-3 bg-slate-950/40">
          <button
            onClick={() => setActiveTab('upload')}
            className={`pb-2.5 text-xs font-semibold border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'upload'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>Upload or Paste Custom Dataset</span>
          </button>

          <button
            onClick={() => setActiveTab('benchmarks')}
            className={`pb-2.5 text-xs font-semibold border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'benchmarks'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sprout className="w-4 h-4" />
            <span>Preset Crop Datasets Library ({BENCHMARK_DATASETS.length})</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {activeTab === 'upload' && (
            <div className="space-y-6">
              {/* Dropzone & Input */}
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragActive(true);
                }}
                onDragLeave={() => setDragActive(false)}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-xl p-6 text-center transition-all ${
                  dragActive
                    ? 'border-emerald-500 bg-emerald-950/20'
                    : 'border-slate-800 hover:border-slate-700 bg-slate-950/50'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv,.tsv,.txt"
                  onChange={handleFileUpload}
                  className="hidden"
                />

                <div className="w-12 h-12 rounded-xl bg-slate-800 text-slate-300 mx-auto flex items-center justify-center mb-3">
                  <FileSpreadsheet className="w-6 h-6 text-emerald-400" />
                </div>

                <div className="space-y-1">
                  <p className="text-sm font-semibold text-white">
                    Drag and drop ANY soil or crop CSV/TSV file here
                  </p>
                  <p className="text-xs text-slate-400">
                    Works with any format, custom column names, or variable crop types.
                  </p>
                </div>

                <div className="mt-4 flex items-center justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold rounded-lg transition-colors shadow-sm"
                  >
                    Browse Local File (.csv, .tsv)
                  </button>
                  <span className="text-xs text-slate-500">or paste tabular data below</span>
                </div>
              </div>

              {/* Paste Textarea */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <label className="font-medium text-slate-300">
                    Paste Raw CSV / TSV Data (with headers)
                  </label>
                  {uploadedFileName && (
                    <span className="text-emerald-400 font-mono text-[11px]">
                      Loaded: {uploadedFileName}
                    </span>
                  )}
                </div>
                <textarea
                  value={csvInput}
                  onChange={(e) => handleProcessText(e.target.value)}
                  placeholder="Paste CSV here e.g.&#10;Nitrogen,Phosphorus,Potassium,pH,Moisture,Rainfall,Crop&#10;90,42,43,6.5,82.0,202.9,rice&#10;71,54,16,5.7,63.7,87.8,maize"
                  rows={4}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              {/* Inspection & Column Mapping */}
              {parseResult && parseResult.headers.length > 0 && (
                <div className="space-y-4 p-4 rounded-xl bg-slate-950/80 border border-slate-800">
                  <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                    <div>
                      <h4 className="text-xs font-bold text-white flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>Dataset Inspected: {parseResult.samples.length} Records Found</span>
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        Verify or adjust column auto-mapping before running PCA and feature engineering.
                      </p>
                    </div>

                    <div className="text-[11px] font-mono text-slate-400 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800">
                      Delimiter: <strong className="text-emerald-400">{parseResult.delimiter === '\t' ? 'TAB' : parseResult.delimiter}</strong> &middot; {parseResult.headers.length} Columns
                    </div>
                  </div>

                  {/* Mapping Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {[
                      { key: 'N', label: 'Nitrogen (N)', req: true },
                      { key: 'P', label: 'Phosphorus (P)', req: true },
                      { key: 'K', label: 'Potassium (K)', req: true },
                      { key: 'ph', label: 'Soil pH', req: true },
                      { key: 'humidity', label: 'Moisture / Humidity', req: false },
                      { key: 'temperature', label: 'Temperature', req: false },
                      { key: 'rainfall', label: 'Rainfall / Water', req: false },
                      { key: 'label', label: 'Crop Label / Variety', req: true },
                    ].map((field) => {
                      const currentVal = userMapping[field.key as keyof ColumnMapping] || '';
                      const isMapped = !!currentVal;

                      return (
                        <div key={field.key} className="space-y-1">
                          <label className="text-[11px] font-medium text-slate-300 flex items-center justify-between">
                            <span>{field.label}</span>
                            {isMapped && (
                              <span className="text-[9px] text-emerald-400 font-mono">Matched</span>
                            )}
                          </label>
                          <select
                            value={currentVal}
                            onChange={(e) =>
                              setUserMapping({ ...userMapping, [field.key]: e.target.value })
                            }
                            className={`w-full bg-slate-900 border rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-500 font-mono ${
                              isMapped ? 'border-emerald-500/50 text-emerald-300' : 'border-slate-800 text-slate-400'
                            }`}
                          >
                            <option value="">-- None / Default --</option>
                            {parseResult.headers.map((h) => (
                              <option key={h} value={h}>
                                {h}
                              </option>
                            ))}
                          </select>
                        </div>
                      );
                    })}
                  </div>

                  {/* Preview Table */}
                  {parseResult.previewRows.length > 0 && (
                    <div className="space-y-1.5 pt-2">
                      <div className="text-[11px] font-medium text-slate-400">
                        First 5 Ingested Rows Preview:
                      </div>
                      <div className="overflow-x-auto rounded-lg border border-slate-800 bg-slate-950">
                        <table className="w-full text-left text-[11px] font-mono">
                          <thead className="bg-slate-900 text-slate-400 border-b border-slate-800">
                            <tr>
                              {parseResult.headers.slice(0, 8).map((h) => (
                                <th key={h} className="p-2 whitespace-nowrap">
                                  {h}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-800/60">
                            {parseResult.previewRows.map((row, rIdx) => (
                              <tr key={rIdx} className="hover:bg-slate-900/40">
                                {parseResult.headers.slice(0, 8).map((h) => (
                                  <td key={h} className="p-2 text-slate-300 whitespace-nowrap">
                                    {row[h]}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {/* Load Button */}
                  <div className="pt-2 flex items-center justify-end">
                    <button
                      onClick={handleLoadCustom}
                      disabled={parseResult.samples.length === 0}
                      className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-bold rounded-lg text-xs transition-all shadow-md shadow-emerald-950 flex items-center gap-2"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>Ingest & Run Soil PCA Pipeline ({parseResult.samples.length} Rows)</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'benchmarks' && (
            <div className="space-y-4">
              <div className="text-xs text-slate-400">
                Select any pre-configured agricultural crop dataset to see how data cleaning, feature engineering, and PCA dynamically adapt to completely different crops and nutrient ranges:
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {BENCHMARK_DATASETS.map((bench) => {
                  const isCurrent = currentDataset.id === bench.id;
                  return (
                    <div
                      key={bench.id}
                      className={`p-4 rounded-xl border transition-all flex flex-col justify-between ${
                        isCurrent
                          ? 'bg-emerald-950/20 border-emerald-500/50'
                          : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                            {bench.category}
                          </span>
                          {isCurrent && (
                            <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" />
                              Active
                            </span>
                          )}
                        </div>

                        <div>
                          <h4 className="text-sm font-bold text-white">{bench.name}</h4>
                          <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                            {bench.description}
                          </p>
                        </div>

                        {/* Crops preview */}
                        <div className="pt-1">
                          <div className="text-[10px] text-slate-500 font-medium mb-1">
                            Crops Included ({bench.cropCount}):
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {bench.crops.slice(0, 6).map((c) => (
                              <span
                                key={c}
                                className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300 capitalize font-mono"
                              >
                                {c}
                              </span>
                            ))}
                            {bench.crops.length > 6 && (
                              <span className="text-[10px] text-slate-500 font-mono self-center">
                                +{bench.crops.length - 6} more
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="pt-4 mt-3 border-t border-slate-800/80 flex items-center justify-between">
                        <span className="text-xs font-mono text-slate-400">
                          {bench.sampleCount} Samples
                        </span>

                        <button
                          onClick={() => handleSelectBenchmark(bench)}
                          disabled={isCurrent}
                          className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                            isCurrent
                              ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                              : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-sm'
                          }`}
                        >
                          <span>{isCurrent ? 'Currently Loaded' : 'Load Dataset'}</span>
                          {!isCurrent && <ArrowRight className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
