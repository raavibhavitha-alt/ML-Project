import React, { useState } from 'react';
import {
  Sliders,
  AlertTriangle,
  CheckCircle,
  RefreshCcw,
  Filter,
  BarChart3,
  HelpCircle,
  FileSpreadsheet,
  Zap,
  ShieldCheck,
  Copy,
  Trash2,
  Sparkles,
} from 'lucide-react';
import { RawSoilSample, CleanedSoilSample, FeatureStats, CleaningAuditReport } from '../types';
import { CleaningOptions, NUMERIC_FEATURES } from '../services/dataCleaning';

interface DataCleaningViewProps {
  rawSamples: RawSoilSample[];
  cleanedSamples: CleanedSoilSample[];
  cleaningOptions: CleaningOptions;
  setCleaningOptions: React.Dispatch<React.SetStateAction<CleaningOptions>>;
  statsBefore: Record<string, FeatureStats>;
  statsAfter: Record<string, FeatureStats>;
  auditReport: CleaningAuditReport;
  onInjectNoise: () => void;
  onRestoreClean: () => void;
  hasNoiseInjected: boolean;
}

export const DataCleaningView: React.FC<DataCleaningViewProps> = ({
  rawSamples,
  cleanedSamples,
  cleaningOptions,
  setCleaningOptions,
  statsBefore,
  statsAfter,
  auditReport,
  onInjectNoise,
  onRestoreClean,
  hasNoiseInjected,
}) => {
  const [selectedFeature, setSelectedFeature] = useState<string>('N');
  const [statsViewMode, setStatsViewMode] = useState<'after' | 'before'>('after');

  const currentStats = statsViewMode === 'after' ? statsAfter : statsBefore;
  const featStat = currentStats[selectedFeature] || statsAfter[selectedFeature];

  return (
    <div className="space-y-6">
      {/* Title & Description */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="text-xs font-mono text-emerald-400 uppercase tracking-wider">Step 1 &middot; Abstract Requirement</div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-0.5">
            Data Cleaning, Imputation & Integrity Preprocessing
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 max-w-3xl mt-1">
            &ldquo;Initially, the collected soil dataset is cleaned by handling missing values, removing duplicate records,
            and correcting inconsistent or invalid data to improve data quality.&rdquo;
          </p>
        </div>

        {/* Noise injection simulation button */}
        <div className="flex items-center gap-2">
          {!hasNoiseInjected ? (
            <button
              onClick={onInjectNoise}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-amber-300 bg-amber-950/40 hover:bg-amber-900/40 border border-amber-800/60 rounded-lg transition-colors whitespace-nowrap"
              title="Inject realistic missing values and invalid extremes to test the cleaning engine"
            >
              <Zap className="w-3.5 h-3.5" />
              Inject Test Artifacts / Nulls
            </button>
          ) : (
            <button
              onClick={onRestoreClean}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/40 border border-emerald-800/60 rounded-lg transition-colors whitespace-nowrap"
            >
              <RefreshCcw className="w-3.5 h-3.5" />
              Restore Baseline Dataset
            </button>
          )}
        </div>
      </div>

      {/* 4 Pillars of Data Cleaning KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono text-slate-400 uppercase">Missing Values Handled</span>
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-mono font-bold text-emerald-400 tabular-nums">
            {auditReport.missingValuesHandled}
          </div>
          <div className="text-[11px] text-slate-400">
            Strategy: <span className="text-slate-200 capitalize font-medium">{cleaningOptions.missingValueStrategy} Imputation</span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono text-slate-400 uppercase">Duplicate Records Removed</span>
            <Copy className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-mono font-bold text-cyan-400 tabular-nums">
            {auditReport.duplicatesRemoved}
          </div>
          <div className="text-[11px] text-slate-400">
            Deduplication: <span className="text-slate-200 font-medium">{cleaningOptions.removeDuplicates ? 'Active' : 'Disabled'}</span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono text-slate-400 uppercase">Inconsistencies Corrected</span>
            <ShieldCheck className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-mono font-bold text-purple-400 tabular-nums">
            {auditReport.inconsistentValuesCorrected}
          </div>
          <div className="text-[11px] text-slate-400">
            Action: <span className="text-slate-200 capitalize font-medium">{cleaningOptions.inconsistencyAction} to physiological bounds</span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono text-slate-400 uppercase">Outliers Flagged / Treated</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-mono font-bold text-amber-400 tabular-nums">
            {auditReport.outliersDetected}
          </div>
          <div className="text-[11px] text-slate-400">
            Method: <span className="text-slate-200 font-medium">{cleaningOptions.outlierMethod.toUpperCase()} ({cleaningOptions.outlierAction})</span>
          </div>
        </div>
      </div>

      {/* Main Interactive Controls & Visualizer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Cleaning Configuration Controls */}
        <div className="lg:col-span-1 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-emerald-400" />
              Preprocessing Pipeline Controls
            </h3>
            <span className="text-[10px] text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              Real-time
            </span>
          </div>

          {/* Module 1: Missing Values Handling */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-white flex items-center justify-between">
              <span>1. Missing Value Imputation Strategy</span>
            </label>
            <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-950 rounded-lg border border-slate-800">
              {[
                { id: 'median', label: 'Median (Robust)' },
                { id: 'mean', label: 'Mean (Parametric)' },
                { id: 'zero', label: 'Zero Fill' },
                { id: 'drop', label: 'Drop Row' },
              ].map(opt => (
                <button
                  key={opt.id}
                  onClick={() =>
                    setCleaningOptions(prev => ({
                      ...prev,
                      missingValueStrategy: opt.id as any,
                    }))
                  }
                  className={`py-1.5 text-xs font-medium rounded transition-colors ${
                    cleaningOptions.missingValueStrategy === opt.id
                      ? 'bg-slate-800 text-emerald-400 font-bold shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
            <p className="text-[11px] text-slate-400">
              Median imputation preserves non-normal skewed distributions without inflating variance.
            </p>
          </div>

          {/* Module 2: Duplicate Removal Toggle */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <label className="flex items-center justify-between text-xs text-white cursor-pointer">
              <span className="font-semibold">2. Remove Duplicate Records</span>
              <input
                type="checkbox"
                checked={cleaningOptions.removeDuplicates}
                onChange={e =>
                  setCleaningOptions(prev => ({
                    ...prev,
                    removeDuplicates: e.target.checked,
                  }))
                }
                className="rounded border-slate-700 bg-slate-950 text-emerald-400 focus:ring-emerald-400"
              />
            </label>
            <p className="text-[11px] text-slate-400">
              Detects identical sample rows across all physicochemical vectors and keeps only unique observations.
            </p>
          </div>

          {/* Module 3: Inconsistent & Invalid Data Correction */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <label className="flex items-center justify-between text-xs text-white cursor-pointer">
              <span className="font-semibold">3. Correct Inconsistent / Invalid Data</span>
              <input
                type="checkbox"
                checked={cleaningOptions.correctInconsistentData}
                onChange={e =>
                  setCleaningOptions(prev => ({
                    ...prev,
                    correctInconsistentData: e.target.checked,
                  }))
                }
                className="rounded border-slate-700 bg-slate-950 text-emerald-400 focus:ring-emerald-400"
              />
            </label>
            <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-950 rounded-lg border border-slate-800">
              <button
                onClick={() => setCleaningOptions(prev => ({ ...prev, inconsistencyAction: 'clamp' }))}
                className={`py-1 text-xs font-medium rounded ${
                  cleaningOptions.inconsistencyAction === 'clamp'
                    ? 'bg-slate-800 text-purple-400 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Clamp to Range
              </button>
              <button
                onClick={() => setCleaningOptions(prev => ({ ...prev, inconsistencyAction: 'drop' }))}
                className={`py-1 text-xs font-medium rounded ${
                  cleaningOptions.inconsistencyAction === 'drop'
                    ? 'bg-slate-800 text-purple-400 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Drop Invalid
              </button>
            </div>
            <p className="text-[11px] text-slate-400">
              Enforces physiological constraints: pH [3.0 - 10.0], Humidity [0 - 100%], Nutrients (N, P, K &ge; 0).
            </p>
          </div>

          {/* Module 4: Outlier Detection */}
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <label className="text-xs font-semibold text-white block">
              4. Statistical Outlier Detection
            </label>
            <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-950 rounded-lg border border-slate-800">
              {['iqr', 'zscore', 'none'].map(m => (
                <button
                  key={m}
                  onClick={() => setCleaningOptions(prev => ({ ...prev, outlierMethod: m as any }))}
                  className={`py-1 text-xs font-medium rounded uppercase ${
                    cleaningOptions.outlierMethod === m
                      ? 'bg-slate-800 text-amber-400 font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>

            {cleaningOptions.outlierMethod === 'iqr' && (
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-slate-400">Tukey Multiplier:</span>
                  <span className="text-amber-400 font-bold">{cleaningOptions.iqrMultiplier.toFixed(1)}&times; IQR</span>
                </div>
                <input
                  type="range"
                  min="1.0"
                  max="3.0"
                  step="0.1"
                  value={cleaningOptions.iqrMultiplier}
                  onChange={e =>
                    setCleaningOptions(prev => ({ ...prev, iqrMultiplier: parseFloat(e.target.value) }))
                  }
                  className="w-full accent-amber-400 h-1.5 bg-slate-950 rounded cursor-pointer"
                />
              </div>
            )}

            {/* Outlier Action */}
            <div className="space-y-1 pt-1">
              <span className="text-[11px] text-slate-400 font-mono">OUTLIER ACTION:</span>
              <div className="grid grid-cols-3 gap-1">
                {['flag', 'winsorize', 'remove'].map(act => (
                  <button
                    key={act}
                    onClick={() => setCleaningOptions(prev => ({ ...prev, outlierAction: act as any }))}
                    className={`py-1 text-[11px] font-mono rounded capitalize border ${
                      cleaningOptions.outlierAction === act
                        ? 'bg-amber-950/40 border-amber-500/50 text-amber-300 font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    {act}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Feature Distribution & Boxplot Inspector */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-emerald-400" />
                  Nutrient Distribution & Outlier Fence
                </h3>
                <span className="text-xs text-slate-400">
                  Select a variable to inspect its median, interquartile range (IQR), and outliers
                </span>
              </div>

              {/* Feature selector buttons */}
              <div className="flex flex-wrap gap-1">
                {NUMERIC_FEATURES.map(f => (
                  <button
                    key={f}
                    onClick={() => setSelectedFeature(f)}
                    className={`px-2.5 py-1 text-xs font-mono rounded transition-colors ${
                      selectedFeature === f
                        ? 'bg-emerald-400 text-slate-950 font-bold'
                        : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>

            {/* SVG Boxplot */}
            {featStat && (
              <div className="space-y-4">
                <div className="bg-slate-950 p-4 rounded-lg border border-slate-800/80">
                  <div className="h-28 w-full relative flex items-center">
                    <svg viewBox="0 0 600 100" className="w-full h-full overflow-visible">
                      <line x1="50" y1="50" x2="550" y2="50" stroke="#334155" strokeWidth="1" />
                      {(() => {
                        const span = featStat.max - featStat.min || 1;
                        const scale = (val: number) => 50 + ((val - featStat.min) / span) * 500;

                        const q1X = scale(featStat.q1);
                        const medX = scale(featStat.median);
                        const q3X = scale(featStat.q3);
                        const minX = scale(featStat.min);
                        const maxX = scale(featStat.max);

                        const k = cleaningOptions.iqrMultiplier;
                        const lowerFence = Math.max(featStat.min, featStat.q1 - k * featStat.iqr);
                        const upperFence = Math.min(featStat.max, featStat.q3 + k * featStat.iqr);
                        const lowerX = scale(lowerFence);
                        const upperX = scale(upperFence);

                        return (
                          <g>
                            <line x1={lowerX} y1="50" x2={q1X} y2="50" stroke="#94A3B8" strokeWidth="2" />
                            <line x1={q3X} y1="50" x2={upperX} y2="50" stroke="#94A3B8" strokeWidth="2" />
                            <line x1={lowerX} y1="35" x2={lowerX} y2="65" stroke="#94A3B8" strokeWidth="2" />
                            <line x1={upperX} y1="35" x2={upperX} y2="65" stroke="#94A3B8" strokeWidth="2" />

                            <rect
                              x={q1X}
                              y="25"
                              width={Math.max(2, q3X - q1X)}
                              height="50"
                              fill="rgba(16, 185, 129, 0.15)"
                              stroke="#10B981"
                              strokeWidth="2"
                              rx="3"
                            />

                            <line x1={medX} y1="25" x2={medX} y2="75" stroke="#34D399" strokeWidth="3" />

                            {cleanedSamples
                              .filter(s => {
                                const v = s[selectedFeature as keyof RawSoilSample] as number;
                                return v < lowerFence || v > upperFence;
                              })
                              .slice(0, 30)
                              .map((s, idx) => (
                                <circle
                                  key={idx}
                                  cx={scale(s[selectedFeature as keyof RawSoilSample] as number)}
                                  cy="50"
                                  r="4"
                                  fill="#F59E0B"
                                  stroke="#78350F"
                                  strokeWidth="1"
                                />
                              ))}

                            <text x={minX} y="90" fill="#64748B" fontSize="10" textAnchor="middle" fontFamily="monospace">
                              Min {featStat.min}
                            </text>
                            <text x={q1X} y="15" fill="#10B981" fontSize="10" textAnchor="middle" fontFamily="monospace">
                              Q1 {featStat.q1}
                            </text>
                            <text x={medX} y="92" fill="#34D399" fontSize="11" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                              Med {featStat.median}
                            </text>
                            <text x={q3X} y="15" fill="#10B981" fontSize="10" textAnchor="middle" fontFamily="monospace">
                              Q3 {featStat.q3}
                            </text>
                            <text x={maxX} y="90" fill="#64748B" fontSize="10" textAnchor="middle" fontFamily="monospace">
                              Max {featStat.max}
                            </text>
                          </g>
                        );
                      })()}
                    </svg>
                  </div>
                </div>

                {/* Key feature stats metric pills */}
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs font-mono">
                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <span className="text-slate-500 block text-[10px]">MEAN</span>
                    <span className="text-slate-200 font-bold">{featStat.mean}</span>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <span className="text-slate-500 block text-[10px]">STD DEV (&sigma;)</span>
                    <span className="text-slate-200 font-bold">{featStat.std}</span>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <span className="text-slate-500 block text-[10px]">IQR SPREAD</span>
                    <span className="text-slate-200 font-bold">{featStat.iqr}</span>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <span className="text-slate-500 block text-[10px]">SKEWNESS</span>
                    <span className={`font-bold ${Math.abs(featStat.skewness) > 1 ? 'text-amber-400' : 'text-emerald-400'}`}>
                      {featStat.skewness}
                    </span>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <span className="text-slate-500 block text-[10px]">MISSING (NaN)</span>
                    <span className="text-emerald-400 font-bold">
                      {featStat.missingCount ?? 0}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Statistical Moments Table */}
          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h4 className="text-xs font-mono text-slate-300 uppercase">
                Data Distribution Metrics ({statsViewMode === 'after' ? 'Cleaned Dataset' : 'Raw Dataset'})
              </h4>
              <div className="flex gap-1 text-[11px] font-mono">
                <button
                  onClick={() => setStatsViewMode('after')}
                  className={`px-2 py-0.5 rounded ${statsViewMode === 'after' ? 'bg-slate-800 text-emerald-400 font-bold' : 'text-slate-400'}`}
                >
                  Cleaned
                </button>
                <button
                  onClick={() => setStatsViewMode('before')}
                  className={`px-2 py-0.5 rounded ${statsViewMode === 'before' ? 'bg-slate-800 text-emerald-400 font-bold' : 'text-slate-400'}`}
                >
                  Raw Input
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono tabular-nums">
                <thead className="text-slate-400 border-b border-slate-800 bg-slate-950">
                  <tr>
                    <th className="py-2 px-2.5">Feature</th>
                    <th className="py-2 px-2.5">Mean</th>
                    <th className="py-2 px-2.5">Std Dev</th>
                    <th className="py-2 px-2.5">Min</th>
                    <th className="py-2 px-2.5">Median</th>
                    <th className="py-2 px-2.5">Max</th>
                    <th className="py-2 px-2.5">Skewness</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {NUMERIC_FEATURES.map(feat => {
                    const s = currentStats[feat];
                    if (!s) return null;
                    return (
                      <tr
                        key={feat}
                        onClick={() => setSelectedFeature(feat)}
                        className={`cursor-pointer hover:bg-slate-800/40 ${selectedFeature === feat ? 'bg-emerald-950/20 text-white' : ''}`}
                      >
                        <td className="py-2 px-2.5 font-bold">{feat}</td>
                        <td className="py-2 px-2.5">{s.mean}</td>
                        <td className="py-2 px-2.5 text-slate-400">{s.std}</td>
                        <td className="py-2 px-2.5">{s.min}</td>
                        <td className="py-2 px-2.5 text-emerald-400 font-semibold">{s.median}</td>
                        <td className="py-2 px-2.5">{s.max}</td>
                        <td className="py-2 px-2.5">{s.skewness}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
