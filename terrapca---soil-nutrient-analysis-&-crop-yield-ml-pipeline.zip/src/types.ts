export interface RawSoilSample {
  id: number;
  N: number;
  P: number;
  K: number;
  temperature: number;
  humidity: number;
  ph: number;
  rainfall: number;
  label: string;
  hasMissingValues?: boolean;
  missingFields?: string[];
  isInconsistent?: boolean;
  inconsistencyNotes?: string[];
}

export interface CleanedSoilSample extends RawSoilSample {
  isOutlier?: boolean;
  outlierFeatures?: string[];
  wasImputed?: boolean;
  imputedFields?: string[];
  wasCorrected?: boolean;
}

export interface EngineeredSoilSample extends CleanedSoilSample {
  totalNPK: number;
  npRatio: number;
  nkRatio: number;
  pkRatio: number;
  moistureIndex: number;
  tempHumidityIndex: number;
  fertilityIndex: number;
  phCategory: 'Acidic' | 'Neutral' | 'Alkaline';
  scaledFeatures: Record<string, number>; // Z-score standardized
}

export interface FeatureStats {
  feature: string;
  count: number;
  mean: number;
  std: number;
  min: number;
  q1: number;
  median: number;
  q3: number;
  max: number;
  iqr: number;
  skewness: number;
  missingCount?: number;
}

export interface CorrelationMatrix {
  features: string[];
  matrix: number[][]; // size N x N
}

export interface MajorFactor {
  component: string; // e.g. "PC1"
  name: string; // e.g. "Potassium & Phosphorus Reserve Factor"
  variancePct: number;
  cumulativePct: number;
  eigenvalue: number;
  topPositiveDrivers: { feature: string; loading: number }[];
  topNegativeDrivers: { feature: string; loading: number }[];
  agronomicDescription: string;
  representativeCrops: string[];
}

export interface PCAResult {
  featureNames: string[];
  eigenvalues: number[];
  eigenvectors: number[][]; // shape: [features][components]
  explainedVariance: number[]; // % per component (0-100)
  cumulativeVariance: number[]; // % cumulative
  loadings: { feature: string; pc1: number; pc2: number; pc3: number; [key: string]: any }[];
  majorFactors: MajorFactor[];
  projectedData: {
    id: number;
    label: string;
    pc1: number;
    pc2: number;
    pc3: number;
    original: RawSoilSample;
  }[];
  totalVariance: number;
  kSelected: number;
}

export interface MLModelEvaluation {
  accuracyOriginal: number; // using all baseline features
  accuracyPCA: number; // using k PCA components
  trainSize: number;
  testSize: number;
  numClasses: number;
  classes: string[];
  confusionMatrix: number[][];
  classMetrics: {
    label: string;
    precision: number;
    recall: number;
    f1: number;
    support: number;
  }[];
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: 'Lead Agronomist' | 'Soil Scientist' | 'Research Scholar' | 'Agricultural Chemist' | 'Guest Researcher';
  institution: string;
  avatar?: string;
  badge?: string;
  lastLogin?: string;
  accessLevel: 'admin' | 'researcher' | 'guest';
}

export interface CropYieldPrediction {
  crop: string;
  suitabilityScore: number; // 0 - 100%
  expectedYieldTonsPerHa: number;
  typicalYieldRange: [number, number];
  yieldEfficiency: number; // % of potential
  limitingFactors: string[];
  amendments: string[];
  pcaCoordinates: { pc1: number; pc2: number; pc3: number };
}

export interface CropAgronomicProfile {
  name: string;
  displayName: string;
  category: 'Cereal' | 'Pulse/Legume' | 'Fruit' | 'Cash Crop' | 'Beverage';
  optN: [number, number];
  optP: [number, number];
  optK: [number, number];
  optPh: [number, number];
  optTemp: [number, number];
  optHumidity: [number, number];
  optRainfall: [number, number];
  avgYieldTonsPerHa: number;
  maxYieldTonsPerHa: number;
  color: string;
}

export interface ColumnMapping {
  N: string;
  P: string;
  K: string;
  temperature?: string;
  humidity?: string;
  ph: string;
  rainfall?: string;
  label: string;
}

export interface DatasetInfo {
  id: string;
  name: string;
  description: string;
  category: 'Benchmark' | 'Custom Upload' | 'Curated Crop File';
  sampleCount: number;
  cropCount: number;
  crops: string[];
  rawText?: string;
  uploadedAt?: string;
}

export interface CleaningAuditReport {
  initialCount: number;
  finalCount: number;
  missingValuesHandled: number;
  duplicatesRemoved: number;
  inconsistentValuesCorrected: number;
  outliersDetected: number;
  outliersTreated: number;
}
