import { RawSoilSample, ColumnMapping, CropAgronomicProfile } from '../types';
import { CROP_PROFILES } from '../data/rawSoilData';

/**
 * Detect delimiter in tabular text (, or \t or ; or |)
 */
export function detectDelimiter(text: string): string {
  const firstLine = text.trim().split('\n')[0] || '';
  const commaCount = (firstLine.match(/,/g) || []).length;
  const tabCount = (firstLine.match(/\t/g) || []).length;
  const semiCount = (firstLine.match(/;/g) || []).length;
  const pipeCount = (firstLine.match(/\|/g) || []).length;

  if (tabCount > commaCount && tabCount > semiCount) return '\t';
  if (semiCount > commaCount && semiCount > pipeCount) return ';';
  if (pipeCount > commaCount) return '|';
  return ',';
}

/**
 * Intelligent Column Heuristics for any soil or crop dataset
 */
export function smartAutoMap(headers: string[]): ColumnMapping {
  const mapping: ColumnMapping = {
    N: '',
    P: '',
    K: '',
    temperature: '',
    humidity: '',
    ph: '',
    rainfall: '',
    label: '',
  };

  const normHeaders = headers.map((h) => ({
    original: h,
    clean: h.trim().toLowerCase().replace(/[\s_\-.]+/g, ''),
  }));

  // 1. Match Nitrogen
  const nMatches = normHeaders.filter((h) =>
    /^(n|nitrogen|nitro|totaln|nkg|nppm|nmgkg|nitrogencontent)$/i.test(h.clean) ||
    h.clean.includes('nitrogen') ||
    h.clean === 'n'
  );
  if (nMatches.length > 0) mapping.N = nMatches[0].original;

  // 2. Match Phosphorus
  const pMatches = normHeaders.filter((h) =>
    /^(p|phosphorus|phosphate|p2o5|pkg|pppm|availp)$/i.test(h.clean) ||
    h.clean.includes('phosphorus') ||
    h.clean === 'p'
  );
  if (pMatches.length > 0) mapping.P = pMatches[0].original;

  // 3. Match Potassium
  const kMatches = normHeaders.filter((h) =>
    /^(k|potassium|potash|k2o|kkg|kppm|availk)$/i.test(h.clean) ||
    h.clean.includes('potassium') ||
    h.clean === 'k'
  );
  if (kMatches.length > 0) mapping.K = kMatches[0].original;

  // 4. Match Soil pH
  const phMatches = normHeaders.filter((h) =>
    /^(ph|soilph|phlevel|phwater|acidity|soilreaction)$/i.test(h.clean) ||
    h.clean.includes('ph')
  );
  if (phMatches.length > 0) mapping.ph = phMatches[0].original;

  // 5. Match Temperature
  const tempMatches = normHeaders.filter((h) =>
    /^(temp|temperature|tempc|airtemp|soiltemp|tmean|t)$/i.test(h.clean) ||
    h.clean.includes('temp')
  );
  if (tempMatches.length > 0) mapping.temperature = tempMatches[0].original;

  // 6. Match Humidity / Moisture
  const humidMatches = normHeaders.filter((h) =>
    /^(humidity|humid|relhumidity|rh|rhpct|moisture|soilmoisture|moist)$/i.test(h.clean) ||
    h.clean.includes('humid') ||
    h.clean.includes('moist')
  );
  if (humidMatches.length > 0) mapping.humidity = humidMatches[0].original;

  // 7. Match Rainfall / Precipitation / Water
  const rainMatches = normHeaders.filter((h) =>
    /^(rainfall|rain|precip|precipitation|water|irrigation|precipmm|watermm)$/i.test(h.clean) ||
    h.clean.includes('rain') ||
    h.clean.includes('precip')
  );
  if (rainMatches.length > 0) mapping.rainfall = rainMatches[0].original;

  // 8. Match Crop Label / Target
  const labelMatches = normHeaders.filter((h) =>
    /^(label|crop|cropname|class|variety|plant|croptype|target|category|species|name)$/i.test(h.clean) ||
    h.clean.includes('crop') ||
    h.clean.includes('label')
  );
  if (labelMatches.length > 0) mapping.label = labelMatches[0].original;

  return mapping;
}

export interface UniversalParseResult {
  samples: RawSoilSample[];
  headers: string[];
  mapping: ColumnMapping;
  delimiter: string;
  previewRows: Record<string, string>[];
  errors: string[];
  totalRawLines: number;
}

/**
 * Universal Parser that accepts ANY soil/crop dataset CSV or TSV
 */
export function parseUniversalCSV(
  csvText: string,
  userMapping?: Partial<ColumnMapping>
): UniversalParseResult {
  const errors: string[] = [];
  const text = csvText.trim();
  if (!text) {
    return {
      samples: [],
      headers: [],
      mapping: { N: '', P: '', K: '', ph: '', label: '' },
      delimiter: ',',
      previewRows: [],
      errors: ['Dataset is empty.'],
      totalRawLines: 0,
    };
  }

  const delimiter = detectDelimiter(text);
  const rawLines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);

  if (rawLines.length < 2) {
    return {
      samples: [],
      headers: [],
      mapping: { N: '', P: '', K: '', ph: '', label: '' },
      delimiter,
      previewRows: [],
      errors: ['Dataset must contain at least a header row and one data row.'],
      totalRawLines: rawLines.length,
    };
  }

  // Parse header
  const headers = splitLine(rawLines[0], delimiter).map((h) =>
    h.replace(/^["']|["']$/g, '').trim()
  );

  const autoMapping = smartAutoMap(headers);
  const mapping: ColumnMapping = {
    ...autoMapping,
    ...userMapping,
  };

  const getIdx = (colName?: string) => {
    if (!colName) return -1;
    return headers.indexOf(colName);
  };

  const idxN = getIdx(mapping.N);
  const idxP = getIdx(mapping.P);
  const idxK = getIdx(mapping.K);
  const idxPh = getIdx(mapping.ph);
  const idxTemp = getIdx(mapping.temperature);
  const idxHumid = getIdx(mapping.humidity);
  const idxRain = getIdx(mapping.rainfall);
  const idxLabel = getIdx(mapping.label);

  const samples: RawSoilSample[] = [];
  const previewRows: Record<string, string>[] = [];

  for (let i = 1; i < rawLines.length; i++) {
    const line = rawLines[i].trim();
    if (!line) continue;
    const parts = splitLine(line, delimiter).map((p) =>
      p.replace(/^["']|["']$/g, '').trim()
    );

    // Save first 5 rows for UI preview
    if (previewRows.length < 5) {
      const rowObj: Record<string, string> = {};
      headers.forEach((h, hIdx) => {
        rowObj[h] = parts[hIdx] ?? '';
      });
      previewRows.push(rowObj);
    }

    const parseNum = (idx: number, fallback = 0) => {
      if (idx === -1 || idx >= parts.length) return fallback;
      const val = parseFloat(parts[idx]);
      return isNaN(val) ? fallback : val;
    };

    const nVal = idxN !== -1 ? parseFloat(parts[idxN]) : 50;
    const pVal = idxP !== -1 ? parseFloat(parts[idxP]) : 40;
    const kVal = idxK !== -1 ? parseFloat(parts[idxK]) : 40;
    const phVal = idxPh !== -1 ? parseFloat(parts[idxPh]) : 6.5;
    const tempVal = idxTemp !== -1 ? parseNum(idxTemp, 25.0) : 25.0;
    const humidVal = idxHumid !== -1 ? parseNum(idxHumid, 70.0) : 70.0;
    const rainVal = idxRain !== -1 ? parseNum(idxRain, 100.0) : 100.0;

    let cropLabel = 'crop_sample';
    if (idxLabel !== -1 && parts[idxLabel]) {
      cropLabel = parts[idxLabel].trim().toLowerCase();
    } else {
      cropLabel = `cluster_${(i % 5) + 1}`;
    }

    const missingFields: string[] = [];
    if (isNaN(nVal)) missingFields.push('N');
    if (isNaN(pVal)) missingFields.push('P');
    if (isNaN(kVal)) missingFields.push('K');
    if (isNaN(phVal)) missingFields.push('ph');

    const inconsistencies: string[] = [];
    if (!isNaN(nVal) && nVal < 0) inconsistencies.push('Negative N');
    if (!isNaN(pVal) && pVal < 0) inconsistencies.push('Negative P');
    if (!isNaN(kVal) && kVal < 0) inconsistencies.push('Negative K');
    if (!isNaN(phVal) && (phVal < 3 || phVal > 11)) inconsistencies.push(`Unusual pH ${phVal}`);

    samples.push({
      id: i,
      N: isNaN(nVal) ? 0 : nVal,
      P: isNaN(pVal) ? 0 : pVal,
      K: isNaN(kVal) ? 0 : kVal,
      temperature: isNaN(tempVal) ? 25.0 : tempVal,
      humidity: isNaN(humidVal) ? 70.0 : humidVal,
      ph: isNaN(phVal) ? 6.5 : phVal,
      rainfall: isNaN(rainVal) ? 100.0 : rainVal,
      label: cropLabel,
      hasMissingValues: missingFields.length > 0,
      missingFields: missingFields.length > 0 ? missingFields : undefined,
      isInconsistent: inconsistencies.length > 0,
      inconsistencyNotes: inconsistencies.length > 0 ? inconsistencies : undefined,
    });
  }

  return {
    samples,
    headers,
    mapping,
    delimiter,
    previewRows,
    errors,
    totalRawLines: rawLines.length - 1,
  };
}

/**
 * Split line by delimiter while respecting quotes
 */
function splitLine(line: string, delimiter: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"' || char === "'") {
      inQuotes = !inQuotes;
    } else if (char === delimiter && !inQuotes) {
      result.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current);
  return result;
}

const SCIENTIFIC_PALETTE = [
  '#10B981', '#06B6D4', '#F59E0B', '#8B5CF6', '#EC4899',
  '#3B82F6', '#84CC16', '#EAB308', '#14B8A6', '#6366F1',
  '#D97706', '#059669', '#0284C7', '#7C3AED', '#DB2777',
  '#4F46E5', '#65A30D', '#CA8A04', '#0D9488', '#9333EA',
];

/**
 * Generates agronomic crop profiles dynamically for ANY crops found in any dataset.
 * Combines existing verified profiles with dynamic inference for any new/custom crops.
 */
export function buildAgronomicProfileMap(
  samples: RawSoilSample[]
): Record<string, CropAgronomicProfile> {
  const profiles: Record<string, CropAgronomicProfile> = { ...CROP_PROFILES };
  const crops = Array.from(new Set(samples.map((s) => s.label))).sort();

  crops.forEach((crop, idx) => {
    if (profiles[crop]) return; // already has verified agronomic profile

    // Infer agronomic envelope from samples
    const cropSamples = samples.filter((s) => s.label === crop);
    if (cropSamples.length === 0) return;

    const calcRange = (accessor: (s: RawSoilSample) => number): [number, number] => {
      const vals = cropSamples.map(accessor).sort((a, b) => a - b);
      const q1 = vals[Math.floor(vals.length * 0.2)] ?? vals[0];
      const q3 = vals[Math.floor(vals.length * 0.8)] ?? vals[vals.length - 1];
      return [Number(q1.toFixed(1)), Number(q3.toFixed(1))];
    };

    const color = SCIENTIFIC_PALETTE[idx % SCIENTIFIC_PALETTE.length];
    const displayName = crop.charAt(0).toUpperCase() + crop.slice(1);

    profiles[crop] = {
      name: crop,
      displayName,
      category: 'Cereal',
      optN: calcRange((s) => s.N),
      optP: calcRange((s) => s.P),
      optK: calcRange((s) => s.K),
      optPh: calcRange((s) => s.ph),
      optTemp: calcRange((s) => s.temperature),
      optHumidity: calcRange((s) => s.humidity),
      optRainfall: calcRange((s) => s.rainfall),
      avgYieldTonsPerHa: 4.5,
      maxYieldTonsPerHa: 8.0,
      color,
    };
  });

  return profiles;
}
