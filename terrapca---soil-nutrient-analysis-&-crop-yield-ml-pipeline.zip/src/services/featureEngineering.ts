import { CleanedSoilSample, EngineeredSoilSample, CorrelationMatrix } from '../types';

export interface AvailableFeature {
  id: string;
  name: string;
  category: 'Nutrient' | 'Chemical' | 'Moisture/Hydrology' | 'Derived Ratio' | 'Climate';
  unit: string;
  description: string;
  isDefault: boolean;
}

export const ALL_AVAILABLE_FEATURES: AvailableFeature[] = [
  {
    id: 'N',
    name: 'Nitrogen (N)',
    category: 'Nutrient',
    unit: 'kg/ha',
    description: 'Vital for vegetative leaf canopy development and chlorophyll formation.',
    isDefault: true,
  },
  {
    id: 'P',
    name: 'Phosphorus (P)',
    category: 'Nutrient',
    unit: 'kg/ha',
    description: 'Essential for root structure elongation, floral bud induction, and energy transfer (ATP).',
    isDefault: true,
  },
  {
    id: 'K',
    name: 'Potassium (K)',
    category: 'Nutrient',
    unit: 'kg/ha',
    description: 'Regulates plant osmoregulation, cellular turgor, and pest/disease resilience.',
    isDefault: true,
  },
  {
    id: 'ph',
    name: 'Soil pH',
    category: 'Chemical',
    unit: 'pH scale',
    description: 'Soil reaction controlling cation exchange capacity (CEC) and micronutrient availability.',
    isDefault: true,
  },
  {
    id: 'moistureIndex',
    name: 'Moisture Index',
    category: 'Moisture/Hydrology',
    unit: 'Index',
    description: 'Engineered biological water metric: Rainfall × (Relative Humidity / 100).',
    isDefault: true,
  },
  {
    id: 'rainfall',
    name: 'Precipitation / Rainfall',
    category: 'Moisture/Hydrology',
    unit: 'mm',
    description: 'Cumulative seasonal rainfall volume influencing root zone leaching and recharge.',
    isDefault: true,
  },
  {
    id: 'humidity',
    name: 'Relative Humidity',
    category: 'Climate',
    unit: '%',
    description: 'Atmospheric moisture controlling transpiration pull and vapor pressure deficit.',
    isDefault: true,
  },
  {
    id: 'temperature',
    name: 'Ambient Temperature',
    category: 'Climate',
    unit: '°C',
    description: 'Thermal energy driving biochemical enzyme kinetics and microbial soil respiration.',
    isDefault: false,
  },
  {
    id: 'totalNPK',
    name: 'Total NPK Pool',
    category: 'Derived Ratio',
    unit: 'kg/ha',
    description: 'Gross primary macronutrient sum (N + P + K) indexing overall fertility load.',
    isDefault: false,
  },
  {
    id: 'npRatio',
    name: 'N:P Stoichiometry',
    category: 'Derived Ratio',
    unit: 'Ratio',
    description: 'Nitrogen-to-Phosphorus balance diagnostic for vegetative vs reproductive partitioning.',
    isDefault: false,
  },
  {
    id: 'nkRatio',
    name: 'N:K Stoichiometry',
    category: 'Derived Ratio',
    unit: 'Ratio',
    description: 'Nitrogen-to-Potassium balance preventing stem lodging and luxury consumption.',
    isDefault: false,
  },
  {
    id: 'pkRatio',
    name: 'P:K Stoichiometry',
    category: 'Derived Ratio',
    unit: 'Ratio',
    description: 'Phosphorus-to-Potassium ratio critical for root-to-fruit sugar translocation.',
    isDefault: false,
  },
];

export const BASE_FEATURE_NAMES = ['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall'];

export interface FeatureScalers {
  means: Record<string, number>;
  stds: Record<string, number>;
}

export function engineerFeatures(samples: CleanedSoilSample[]): {
  engineered: EngineeredSoilSample[];
  scalers: FeatureScalers;
  correlationMatrix: CorrelationMatrix;
} {
  // Step 1: Compute derived agronomic features
  const unscaled = samples.map(s => {
    const totalNPK = Math.round((s.N + s.P + s.K) * 10) / 10;
    const npRatio = Number((s.N / (s.P + 0.001)).toFixed(3));
    const nkRatio = Number((s.N / (s.K + 0.001)).toFixed(3));
    const pkRatio = Number((s.P / (s.K + 0.001)).toFixed(3));
    // Moisture Index: rainfall weighted by relative humidity
    const moistureIndex = Number((s.rainfall * (s.humidity / 100)).toFixed(2));
    const tempHumidityIndex = Number(
      (0.8 * s.temperature + (s.humidity * (s.temperature - 14.4)) / 100 + 46.4).toFixed(2)
    );

    // Soil Fertility Index (0 - 100 benchmark)
    const nScore = Math.min(1, s.N / 120);
    const pScore = Math.min(1, s.P / 120);
    const kScore = Math.min(1, s.K / 180);
    const phScore = 1 - Math.abs(s.ph - 6.5) / 3.5;
    const fertilityIndex = Number(((nScore * 0.3 + pScore * 0.3 + kScore * 0.3 + Math.max(0, phScore) * 0.1) * 100).toFixed(1));

    let phCategory: 'Acidic' | 'Neutral' | 'Alkaline' = 'Neutral';
    if (s.ph < 6.0) phCategory = 'Acidic';
    else if (s.ph > 7.5) phCategory = 'Alkaline';

    return {
      ...s,
      totalNPK,
      npRatio,
      nkRatio,
      pkRatio,
      moistureIndex,
      tempHumidityIndex,
      fertilityIndex,
      phCategory,
    };
  });

  // Step 2: Compute means and stds for standard scaling across all features
  const allFeatureKeys = ALL_AVAILABLE_FEATURES.map(f => f.id);
  const means: Record<string, number> = {};
  const stds: Record<string, number> = {};
  const n = unscaled.length;

  for (const feat of allFeatureKeys) {
    const values = unscaled.map(s => (s as unknown as Record<string, number>)[feat] ?? 0);
    const mean = values.reduce((a, b) => a + b, 0) / (n || 1);
    const variance = values.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / (n > 1 ? n - 1 : 1);
    const std = Math.sqrt(variance) || 1;
    means[feat] = Number(mean.toFixed(3));
    stds[feat] = Number(std.toFixed(3));
  }

  // Step 3: Add Z-scores
  const engineered: EngineeredSoilSample[] = unscaled.map(s => {
    const scaledFeatures: Record<string, number> = {};
    for (const feat of allFeatureKeys) {
      const val = (s as unknown as Record<string, number>)[feat] ?? 0;
      scaledFeatures[feat] = Number(((val - means[feat]) / (stds[feat] || 1)).toFixed(4));
    }
    return {
      ...s,
      scaledFeatures,
    };
  });

  // Step 4: Compute Pearson Correlation Matrix
  const correlationMatrix = computeCorrelationMatrix(unscaled, allFeatureKeys);

  return {
    engineered,
    scalers: { means, stds },
    correlationMatrix,
  };
}

export function computeCorrelationMatrix(
  samples: CleanedSoilSample[],
  features: string[]
): CorrelationMatrix {
  const n = samples.length;
  const matrix: number[][] = [];

  const vectors: Record<string, number[]> = {};
  const vecMeans: Record<string, number> = {};
  const vecStds: Record<string, number> = {};

  for (const f of features) {
    const vals = samples.map(s => (s as unknown as Record<string, number>)[f] ?? 0);
    vectors[f] = vals;
    const mean = vals.reduce((a, b) => a + b, 0) / (n || 1);
    vecMeans[f] = mean;
    const std = Math.sqrt(vals.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / (n || 1)) || 1;
    vecStds[f] = std;
  }

  for (let i = 0; i < features.length; i++) {
    const row: number[] = [];
    const f1 = features[i];
    for (let j = 0; j < features.length; j++) {
      if (i === j) {
        row.push(1.0);
        continue;
      }
      const f2 = features[j];
      let cov = 0;
      for (let k = 0; k < n; k++) {
        cov += (vectors[f1][k] - vecMeans[f1]) * (vectors[f2][k] - vecMeans[f2]);
      }
      cov /= n || 1;
      const r = cov / (vecStds[f1] * vecStds[f2]);
      row.push(Number(r.toFixed(3)));
    }
    matrix.push(row);
  }

  return {
    features,
    matrix,
  };
}
