import { RawSoilSample, CleanedSoilSample, FeatureStats, CleaningAuditReport } from '../types';

export interface CleaningOptions {
  // 1. Missing Values
  missingValueStrategy: 'median' | 'mean' | 'zero' | 'drop';
  // 2. Duplicate Records
  removeDuplicates: boolean;
  // 3. Inconsistent & Invalid Data Correction
  correctInconsistentData: boolean;
  inconsistencyAction: 'clamp' | 'impute' | 'drop';
  // 4. Outlier Detection & Treatment
  outlierMethod: 'iqr' | 'zscore' | 'none';
  iqrMultiplier: number; // e.g. 1.5 for standard, 3.0 for extreme
  zThreshold: number; // e.g. 3.0
  outlierAction: 'flag' | 'remove' | 'winsorize';
}

export const DEFAULT_CLEANING_OPTIONS: CleaningOptions = {
  missingValueStrategy: 'median',
  removeDuplicates: true,
  correctInconsistentData: true,
  inconsistencyAction: 'clamp',
  outlierMethod: 'iqr',
  iqrMultiplier: 1.5,
  zThreshold: 3.0,
  outlierAction: 'flag',
};

export const NUMERIC_FEATURES: (keyof Omit<RawSoilSample, 'id' | 'label' | 'hasMissingValues' | 'missingFields' | 'isInconsistent' | 'inconsistencyNotes'>)[] = [
  'N',
  'P',
  'K',
  'temperature',
  'humidity',
  'ph',
  'rainfall',
];

export function computeFeatureStats(
  samples: RawSoilSample[],
  feature: keyof Omit<RawSoilSample, 'id' | 'label' | 'hasMissingValues' | 'missingFields' | 'isInconsistent' | 'inconsistencyNotes'>
): FeatureStats {
  if (samples.length === 0) {
    return {
      feature,
      count: 0,
      mean: 0,
      std: 0,
      min: 0,
      q1: 0,
      median: 0,
      q3: 0,
      max: 0,
      iqr: 0,
      skewness: 0,
      missingCount: 0,
    };
  }

  let missingCount = 0;
  const values: number[] = [];

  for (const s of samples) {
    const val = s[feature];
    if (val === undefined || val === null || isNaN(val)) {
      missingCount++;
    } else {
      values.push(val);
    }
  }

  if (values.length === 0) {
    return {
      feature,
      count: 0,
      mean: 0,
      std: 0,
      min: 0,
      q1: 0,
      median: 0,
      q3: 0,
      max: 0,
      iqr: 0,
      skewness: 0,
      missingCount,
    };
  }

  values.sort((a, b) => a - b);
  const n = values.length;

  const sum = values.reduce((acc, v) => acc + v, 0);
  const mean = sum / n;

  const variance = values.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / (n > 1 ? n - 1 : 1);
  const std = Math.sqrt(variance);

  const getPercentile = (p: number) => {
    const idx = (n - 1) * p;
    const lower = Math.floor(idx);
    const upper = Math.ceil(idx);
    const weight = idx - lower;
    return values[lower] * (1 - weight) + values[upper] * weight;
  };

  const min = values[0];
  const max = values[n - 1];
  const q1 = getPercentile(0.25);
  const median = getPercentile(0.5);
  const q3 = getPercentile(0.75);
  const iqr = q3 - q1;

  let m3 = 0;
  for (const v of values) {
    m3 += Math.pow((v - mean) / (std || 1), 3);
  }
  const skewness = n > 2 ? (n / ((n - 1) * (n - 2))) * m3 : 0;

  return {
    feature,
    count: n,
    mean: Number(mean.toFixed(3)),
    std: Number(std.toFixed(3)),
    min: Number(min.toFixed(3)),
    q1: Number(q1.toFixed(3)),
    median: Number(median.toFixed(3)),
    q3: Number(q3.toFixed(3)),
    max: Number(max.toFixed(3)),
    iqr: Number(iqr.toFixed(3)),
    skewness: Number(skewness.toFixed(3)),
    missingCount,
  };
}

export function cleanSoilData(
  samples: RawSoilSample[],
  options: CleaningOptions = DEFAULT_CLEANING_OPTIONS
): {
  cleaned: CleanedSoilSample[];
  auditReport: CleaningAuditReport;
  statsBefore: Record<string, FeatureStats>;
  statsAfter: Record<string, FeatureStats>;
} {
  const initialCount = samples.length;
  const statsBefore: Record<string, FeatureStats> = {};
  for (const feat of NUMERIC_FEATURES) {
    statsBefore[feat] = computeFeatureStats(samples, feat);
  }

  let work: RawSoilSample[] = samples.map(s => ({ ...s }));
  let duplicatesRemoved = 0;
  let missingValuesHandled = 0;
  let inconsistentValuesCorrected = 0;

  // STEP 1: Handle Missing Values
  if (options.missingValueStrategy === 'drop') {
    const prevCount = work.length;
    work = work.filter(s => {
      for (const feat of NUMERIC_FEATURES) {
        const v = s[feat];
        if (v === undefined || v === null || isNaN(v)) return false;
      }
      return true;
    });
    missingValuesHandled += prevCount - work.length;
  } else {
    // Impute
    work = work.map(s => {
      const copy = { ...s };
      const imputedFields: string[] = [];

      for (const feat of NUMERIC_FEATURES) {
        const val = copy[feat];
        if (val === undefined || val === null || isNaN(val)) {
          let replacement = 0;
          if (options.missingValueStrategy === 'median') {
            replacement = statsBefore[feat]?.median ?? 50;
          } else if (options.missingValueStrategy === 'mean') {
            replacement = statsBefore[feat]?.mean ?? 50;
          } else if (options.missingValueStrategy === 'zero') {
            replacement = 0;
          }
          copy[feat] = Number(replacement.toFixed(2));
          imputedFields.push(feat);
          missingValuesHandled++;
        }
      }

      if (imputedFields.length > 0) {
        (copy as CleanedSoilSample).wasImputed = true;
        (copy as CleanedSoilSample).imputedFields = imputedFields;
      }
      return copy;
    });
  }

  // STEP 2: Remove Duplicate Records
  if (options.removeDuplicates) {
    const seen = new Set<string>();
    const unique: RawSoilSample[] = [];
    for (const s of work) {
      const key = `${s.N.toFixed(1)}_${s.P.toFixed(1)}_${s.K.toFixed(1)}_${s.temperature.toFixed(2)}_${s.humidity.toFixed(2)}_${s.ph.toFixed(2)}_${s.rainfall.toFixed(2)}_${s.label}`;
      if (!seen.has(key)) {
        seen.add(key);
        unique.push(s);
      } else {
        duplicatesRemoved++;
      }
    }
    work = unique;
  }

  // STEP 3: Correct Inconsistent or Invalid Data
  // Physiological / agronomic valid ranges:
  // pH: [3.0, 10.0]
  // Humidity: [0, 100]
  // N, P, K: >= 0
  // Rainfall: >= 0
  // Temperature: [-5, 55]
  if (options.correctInconsistentData) {
    if (options.inconsistencyAction === 'drop') {
      const prevCount = work.length;
      work = work.filter(s => {
        const valid =
          s.ph >= 3.0 &&
          s.ph <= 10.0 &&
          s.humidity >= 0 &&
          s.humidity <= 100 &&
          s.N >= 0 &&
          s.P >= 0 &&
          s.K >= 0 &&
          s.rainfall >= 0 &&
          s.temperature >= -5 &&
          s.temperature <= 55;
        return valid;
      });
      inconsistentValuesCorrected += prevCount - work.length;
    } else {
      // Clamping / Correction
      work = work.map(s => {
        let changed = false;
        const copy = { ...s };

        if (copy.ph < 3.0) {
          copy.ph = 3.0;
          changed = true;
        } else if (copy.ph > 10.0) {
          copy.ph = 10.0;
          changed = true;
        }

        if (copy.humidity < 0) {
          copy.humidity = 0;
          changed = true;
        } else if (copy.humidity > 100) {
          copy.humidity = 100;
          changed = true;
        }

        if (copy.N < 0) {
          copy.N = 0;
          changed = true;
        }
        if (copy.P < 0) {
          copy.P = 0;
          changed = true;
        }
        if (copy.K < 0) {
          copy.K = 0;
          changed = true;
        }
        if (copy.rainfall < 0) {
          copy.rainfall = 0;
          changed = true;
        }

        if (copy.temperature < -5) {
          copy.temperature = -5;
          changed = true;
        } else if (copy.temperature > 55) {
          copy.temperature = 55;
          changed = true;
        }

        if (changed) {
          inconsistentValuesCorrected++;
          (copy as CleanedSoilSample).wasCorrected = true;
        }
        return copy;
      });
    }
  }

  // STEP 4: Outlier Detection and Treatment
  const featureFences: Record<string, { lower: number; upper: number }> = {};
  for (const feat of NUMERIC_FEATURES) {
    const stat = statsBefore[feat];
    if (options.outlierMethod === 'iqr') {
      const k = options.iqrMultiplier;
      featureFences[feat] = {
        lower: stat.q1 - k * stat.iqr,
        upper: stat.q3 + k * stat.iqr,
      };
    } else if (options.outlierMethod === 'zscore') {
      const t = options.zThreshold;
      featureFences[feat] = {
        lower: stat.mean - t * stat.std,
        upper: stat.mean + t * stat.std,
      };
    } else {
      featureFences[feat] = { lower: -Infinity, upper: Infinity };
    }
  }

  let outliersDetected = 0;
  let outliersTreated = 0;
  const processed: CleanedSoilSample[] = [];

  for (const s of work) {
    const outlierFeats: string[] = [];
    const modified: CleanedSoilSample = { ...s };

    for (const feat of NUMERIC_FEATURES) {
      const val = s[feat];
      const fence = featureFences[feat];
      if (val < fence.lower || val > fence.upper) {
        outlierFeats.push(feat);
        if (options.outlierAction === 'winsorize') {
          modified[feat] = Math.max(fence.lower, Math.min(fence.upper, val));
          outliersTreated++;
        }
      }
    }

    const isOutlier = outlierFeats.length > 0;
    if (isOutlier) {
      outliersDetected++;
    }

    if (isOutlier && options.outlierAction === 'remove') {
      outliersTreated++;
      continue;
    }

    modified.isOutlier = isOutlier;
    modified.outlierFeatures = outlierFeats;
    processed.push(modified);
  }

  const statsAfter: Record<string, FeatureStats> = {};
  for (const feat of NUMERIC_FEATURES) {
    statsAfter[feat] = computeFeatureStats(processed, feat);
  }

  const auditReport: CleaningAuditReport = {
    initialCount,
    finalCount: processed.length,
    missingValuesHandled,
    duplicatesRemoved,
    inconsistentValuesCorrected,
    outliersDetected,
    outliersTreated,
  };

  return {
    cleaned: processed,
    auditReport,
    statsBefore,
    statsAfter,
  };
}

/**
 * Creates synthetic anomalies / missing values for interactive demonstration
 * of data cleaning effectiveness.
 */
export function injectSyntheticArtifacts(samples: RawSoilSample[]): RawSoilSample[] {
  return samples.map((s, idx) => {
    const clone = { ...s };
    // Inject missing value in 4% of samples
    if (idx % 25 === 3) {
      (clone as any).N = null;
      clone.hasMissingValues = true;
      clone.missingFields = ['N'];
    } else if (idx % 25 === 11) {
      (clone as any).ph = null;
      clone.hasMissingValues = true;
      clone.missingFields = ['ph'];
    }
    // Inject invalid/inconsistent value in 3% of samples
    if (idx % 33 === 5) {
      clone.ph = 14.8; // impossible high alkaline
      clone.isInconsistent = true;
      clone.inconsistencyNotes = ['pH exceeds maximum boundary'];
    } else if (idx % 33 === 17) {
      clone.humidity = 135; // invalid humidity > 100
      clone.isInconsistent = true;
      clone.inconsistencyNotes = ['Humidity exceeds 100%'];
    } else if (idx % 33 === 22) {
      clone.K = -12; // negative nutrient
      clone.isInconsistent = true;
      clone.inconsistencyNotes = ['Negative Potassium value'];
    }
    return clone;
  });
}
