import {
  EngineeredSoilSample,
  PCAResult,
  MLModelEvaluation,
  CropYieldPrediction,
  CropAgronomicProfile,
} from '../types';
import { CROP_PROFILES } from '../data/rawSoilData';
import { FeatureScalers } from './featureEngineering';
import { projectSampleToPCA } from './pcaEngine';

export interface ModelTrainingConfig {
  trainSplitRatio: number; // e.g. 0.8
  kNeighbors: number; // e.g. 5
  kPCAComponents: number; // e.g. 3
}

export function evaluateModels(
  samples: EngineeredSoilSample[],
  pcaResult: PCAResult,
  baseFeatures: string[],
  config: ModelTrainingConfig = { trainSplitRatio: 0.8, kNeighbors: 5, kPCAComponents: 3 }
): MLModelEvaluation {
  const n = samples.length;
  if (n < 10) {
    return {
      accuracyOriginal: 0,
      accuracyPCA: 0,
      trainSize: 0,
      testSize: 0,
      numClasses: 0,
      classes: [],
      confusionMatrix: [],
      classMetrics: [],
    };
  }

  // Shuffle reproducibly using a deterministic seed-based shuffle
  const indices = Array.from({ length: n }, (_, i) => i);
  // Simple LCG shuffle
  let seed = 42;
  const lcg = () => {
    seed = (seed * 1664525 + 1013904223) % 4294967296;
    return seed / 4294967296;
  };
  for (let i = indices.length - 1; i > 0; i--) {
    const j = Math.floor(lcg() * (i + 1));
    [indices[i], indices[j]] = [indices[j], indices[i]];
  }

  const splitIdx = Math.floor(n * config.trainSplitRatio);
  const trainIndices = indices.slice(0, splitIdx);
  const testIndices = indices.slice(splitIdx);

  const classes = Array.from(new Set(samples.map(s => s.label))).sort();
  const classToIdx: Record<string, number> = {};
  classes.forEach((c, idx) => {
    classToIdx[c] = idx;
  });

  // Prepare Feature Matrices for Train & Test
  // 1. Original features (standardized)
  const trainOrigX = trainIndices.map(idx =>
    baseFeatures.map(f => samples[idx].scaledFeatures[f] ?? 0)
  );
  const trainOrigY = trainIndices.map(idx => samples[idx].label);

  const testOrigX = testIndices.map(idx =>
    baseFeatures.map(f => samples[idx].scaledFeatures[f] ?? 0)
  );
  const testOrigY = testIndices.map(idx => samples[idx].label);

  // 2. PCA components (k components)
  const kComp = Math.min(config.kPCAComponents, pcaResult.kSelected, pcaResult.eigenvectors.length);
  const trainPcaX = trainIndices.map(idx => {
    const p = pcaResult.projectedData[idx];
    return [p.pc1, p.pc2, p.pc3].slice(0, kComp);
  });
  const testPcaX = testIndices.map(idx => {
    const p = pcaResult.projectedData[idx];
    return [p.pc1, p.pc2, p.pc3].slice(0, kComp);
  });

  // KNN Predictor
  const predictKNN = (trainX: number[][], trainY: string[], query: number[], k: number): string => {
    const dists = trainX.map((x, i) => {
      let d = 0;
      for (let j = 0; j < query.length; j++) {
        d += (x[j] - query[j]) * (x[j] - query[j]);
      }
      return { dist: d, label: trainY[i] };
    });

    dists.sort((a, b) => a.dist - b.dist);
    const votes: Record<string, number> = {};
    const topK = dists.slice(0, k);

    for (const item of topK) {
      // inverse distance weighting with epsilon
      const weight = 1 / (Math.sqrt(item.dist) + 0.001);
      votes[item.label] = (votes[item.label] || 0) + weight;
    }

    let bestLabel = topK[0].label;
    let maxVote = -1;
    for (const [lbl, vote] of Object.entries(votes)) {
      if (vote > maxVote) {
        maxVote = vote;
        bestLabel = lbl;
      }
    }
    return bestLabel;
  };

  // Evaluate Original Features
  let correctOrig = 0;
  for (let i = 0; i < testOrigX.length; i++) {
    const pred = predictKNN(trainOrigX, trainOrigY, testOrigX[i], config.kNeighbors);
    if (pred === testOrigY[i]) {
      correctOrig++;
    }
  }
  const accuracyOriginal = Number(((correctOrig / testOrigX.length) * 100).toFixed(1));

  // Evaluate PCA Features and compute Confusion Matrix
  let correctPCA = 0;
  const numClasses = classes.length;
  const confusionMatrix: number[][] = Array.from({ length: numClasses }, () =>
    Array(numClasses).fill(0)
  );

  const predictionsPCA: string[] = [];
  for (let i = 0; i < testPcaX.length; i++) {
    const actual = testOrigY[i];
    const pred = predictKNN(trainPcaX, trainOrigY, testPcaX[i], config.kNeighbors);
    predictionsPCA.push(pred);

    if (pred === actual) {
      correctPCA++;
    }

    const actualIdx = classToIdx[actual] ?? 0;
    const predIdx = classToIdx[pred] ?? 0;
    confusionMatrix[actualIdx][predIdx]++;
  }
  const accuracyPCA = Number(((correctPCA / testPcaX.length) * 100).toFixed(1));

  // Compute Class-level Precision, Recall, F1
  const classMetrics = classes.map((label, cIdx) => {
    let tp = confusionMatrix[cIdx][cIdx];
    let fn = 0; // row sum minus TP
    for (let j = 0; j < numClasses; j++) {
      if (j !== cIdx) fn += confusionMatrix[cIdx][j];
    }
    let fp = 0; // col sum minus TP
    for (let i = 0; i < numClasses; i++) {
      if (i !== cIdx) fp += confusionMatrix[i][cIdx];
    }

    const precision = tp + fp > 0 ? tp / (tp + fp) : 0;
    const recall = tp + fn > 0 ? tp / (tp + fn) : 0;
    const f1 = precision + recall > 0 ? (2 * precision * recall) / (precision + recall) : 0;
    const support = tp + fn;

    return {
      label,
      precision: Number((precision * 100).toFixed(1)),
      recall: Number((recall * 100).toFixed(1)),
      f1: Number((f1 * 100).toFixed(1)),
      support,
    };
  });

  return {
    accuracyOriginal,
    accuracyPCA,
    trainSize: trainIndices.length,
    testSize: testIndices.length,
    numClasses,
    classes,
    confusionMatrix,
    classMetrics,
  };
}

/**
 * Predicts crop suitability, yield in tons/ha, limiting factors, and nutrient amendments
 * for arbitrary soil conditions.
 */
export function predictCropYield(
  input: {
    N: number;
    P: number;
    K: number;
    temperature: number;
    humidity: number;
    ph: number;
    rainfall: number;
  },
  featureNames: string[],
  scalers: FeatureScalers,
  pcaResult: PCAResult,
  customProfiles?: Record<string, CropAgronomicProfile>
): CropYieldPrediction[] {
  // 1. Calculate PCA Coordinates of input sample
  const sampleValues: Record<string, number> = {
    ...input,
    totalNPK: input.N + input.P + input.K,
    npRatio: input.N / (input.P + 0.001),
    nkRatio: input.N / (input.K + 0.001),
    pkRatio: input.P / (input.K + 0.001),
    moistureIndex: input.rainfall * (input.humidity / 100),
  };
  const pcaCoords = projectSampleToPCA(sampleValues, featureNames, scalers, pcaResult);

  // 2. Evaluate against each crop profile
  const results: CropYieldPrediction[] = [];
  const profiles = customProfiles || CROP_PROFILES;

  for (const [cropKey, profile] of Object.entries(profiles)) {
    let penalty = 0;
    const limitingFactors: string[] = [];
    const amendments: string[] = [];

    // Helper for interval tolerance with soft penalty
    const checkRange = (
      val: number,
      range: [number, number],
      name: string,
      unit: string,
      weight = 1.0
    ) => {
      const [min, max] = range;
      if (val < min) {
        const diffRatio = (min - val) / (max - min || 1);
        penalty += diffRatio * 25 * weight;
        limitingFactors.push(`Low ${name} (${val.toFixed(1)} ${unit} vs req ${min}-${max})`);
      } else if (val > max) {
        const diffRatio = (val - max) / (max - min || 1);
        penalty += diffRatio * 20 * weight;
        limitingFactors.push(`Excess ${name} (${val.toFixed(1)} ${unit} vs req ${min}-${max})`);
      }
    };

    checkRange(input.N, profile.optN, 'Nitrogen (N)', 'kg/ha', 1.2);
    checkRange(input.P, profile.optP, 'Phosphorus (P)', 'kg/ha', 1.1);
    checkRange(input.K, profile.optK, 'Potassium (K)', 'kg/ha', 1.1);
    checkRange(input.ph, profile.optPh, 'Soil pH', '', 1.3);
    checkRange(input.temperature, profile.optTemp, 'Temperature', '°C', 1.0);
    checkRange(input.humidity, profile.optHumidity, 'Humidity', '%', 0.9);
    checkRange(input.rainfall, profile.optRainfall, 'Rainfall', 'mm', 1.1);

    // Formulate practical agronomic fertilizer / soil treatment advice
    if (input.N < profile.optN[0]) {
      const deficit = profile.optN[0] - input.N;
      const ureaKg = Math.round(deficit * 2.17); // Urea is 46% N
      amendments.push(`Apply ~${ureaKg} kg/ha Urea to compensate for ${Math.round(deficit)} kg/ha N deficiency.`);
    }
    if (input.P < profile.optP[0]) {
      const deficit = profile.optP[0] - input.P;
      const dapKg = Math.round(deficit * 2.17); // DAP is 46% P2O5
      amendments.push(`Apply ~${dapKg} kg/ha Diammonium Phosphate (DAP) for root development.`);
    }
    if (input.K < profile.optK[0]) {
      const deficit = profile.optK[0] - input.K;
      const mopKg = Math.round(deficit * 1.67); // Muriate of Potash is 60% K2O
      amendments.push(`Apply ~${mopKg} kg/ha MOP (Muriate of Potash) for drought & pest resistance.`);
    }
    if (input.ph < profile.optPh[0]) {
      amendments.push(`Soil is acidic (pH ${input.ph.toFixed(1)}): Broadcast 500-1000 kg/ha Agricultural Lime (CaCO3) to neutralize.`);
    } else if (input.ph > profile.optPh[1]) {
      amendments.push(`Soil is alkaline (pH ${input.ph.toFixed(1)}): Apply Gypsum (CaSO4) or organic compost to lower pH.`);
    }
    if (input.rainfall < profile.optRainfall[0] * 0.7) {
      amendments.push(`Hydric stress: Implement drip irrigation to supplement natural rainfall shortfall.`);
    }

    const suitabilityScore = Math.max(5, Math.min(99, Math.round(100 - penalty)));
    const yieldEfficiency = Number((Math.max(0.2, suitabilityScore / 100)).toFixed(2));
    const expectedYield = Number(
      (profile.avgYieldTonsPerHa * (0.4 + 0.6 * yieldEfficiency)).toFixed(2)
    );
    const minYield = Number((expectedYield * 0.85).toFixed(2));
    const maxYield = Number((Math.min(profile.maxYieldTonsPerHa, expectedYield * 1.25)).toFixed(2));

    results.push({
      crop: cropKey,
      suitabilityScore,
      expectedYieldTonsPerHa: expectedYield,
      typicalYieldRange: [minYield, maxYield],
      yieldEfficiency: Math.round(yieldEfficiency * 100),
      limitingFactors,
      amendments,
      pcaCoordinates: pcaCoords,
    });
  }

  // Sort by suitability descending
  results.sort((a, b) => b.suitabilityScore - a.suitabilityScore);
  return results;
}
