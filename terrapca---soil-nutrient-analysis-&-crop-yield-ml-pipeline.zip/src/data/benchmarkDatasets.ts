import { RAW_SOIL_CSV } from './rawSoilData';
import { DatasetInfo } from '../types';

export const BENCHMARK_DATASETS: DatasetInfo[] = [
  {
    id: 'crop_recommendation_master',
    name: 'Crop_recommendation.csv (Master 22-Crop Dataset)',
    description: 'Comprehensive agricultural dataset with 2,200 records covering cereals, pulses, fruits, and commercial cash crops with N, P, K, pH, humidity, and rainfall.',
    category: 'Benchmark',
    sampleCount: 2200,
    cropCount: 22,
    crops: [
      'rice', 'maize', 'chickpea', 'kidneybeans', 'pigeonpeas',
      'mothbeans', 'mungbean', 'blackgram', 'lentil', 'pomegranate',
      'banana', 'mango', 'grapes', 'watermelon', 'muskmelon',
      'apple', 'orange', 'papaya', 'coconut', 'cotton', 'jute', 'coffee',
    ],
    rawText: RAW_SOIL_CSV,
  },
  {
    id: 'cereals_soil_data',
    name: 'Cereals & Staple Grains Crop File',
    description: 'Focused soil profile dataset for high-starch staple grains: Rice, Maize, Wheat, Barley, and Sorghum with distinct high-nitrogen fertilizer requirements.',
    category: 'Curated Crop File',
    sampleCount: 500,
    cropCount: 5,
    crops: ['rice', 'maize', 'wheat', 'barley', 'sorghum'],
    rawText: `N,P,K,temperature,humidity,ph,rainfall,label
90,42,43,20.87,82.00,6.50,202.93,rice
85,58,41,21.77,80.31,7.03,226.65,rice
60,55,44,23.00,82.32,7.84,263.96,rice
74,35,40,26.49,80.15,6.98,242.86,rice
78,42,42,20.13,81.60,7.62,262.71,rice
94,53,40,20.27,82.89,5.71,241.97,rice
89,54,38,24.51,83.53,6.68,230.44,rice
71,54,16,22.61,63.69,5.74,87.75,maize
61,44,17,26.10,71.57,6.93,102.26,maize
80,43,16,23.55,71.59,6.65,66.71,maize
73,58,21,19.97,57.68,6.59,60.65,maize
68,41,16,21.77,57.80,6.15,102.08,maize
93,41,17,25.62,66.50,6.04,105.46,maize
89,60,19,25.19,66.69,5.91,78.06,maize
110,48,35,16.82,65.20,6.42,75.40,wheat
115,52,38,17.40,62.80,6.80,82.10,wheat
105,45,30,15.90,68.10,6.10,70.50,wheat
120,55,40,18.10,59.40,7.10,88.90,wheat
98,40,32,16.20,64.50,6.60,68.20,wheat
112,50,36,17.90,63.10,6.35,79.00,wheat
80,35,25,18.50,55.20,7.20,52.40,barley
85,38,28,19.20,52.80,7.50,58.10,barley
78,32,22,17.80,58.40,6.90,49.80,barley
82,36,26,18.90,54.10,7.30,55.20,barley
65,30,20,28.40,48.20,6.80,45.20,sorghum
70,34,22,29.10,45.80,7.10,48.90,sorghum
62,28,18,27.90,51.00,6.50,42.10,sorghum
68,32,21,28.80,46.50,6.95,46.80,sorghum`,
  },
  {
    id: 'pulses_legumes_data',
    name: 'Legumes & Pulses Soil File (Nitrogen-Fixing Crops)',
    description: 'Agronomic profile for protein-rich pulse crops: Chickpea, Lentil, Blackgram, Mungbean, and Kidneybeans with low-nitrogen symbiotic requirement and high phosphorus demand.',
    category: 'Curated Crop File',
    sampleCount: 500,
    cropCount: 5,
    crops: ['chickpea', 'lentil', 'blackgram', 'mungbean', 'kidneybeans'],
    rawText: `N,P,K,temperature,humidity,ph,rainfall,label
40,68,79,17.02,16.98,7.48,88.55,chickpea
23,72,84,19.02,17.13,7.33,79.85,chickpea
39,58,85,17.88,15.40,5.99,94.73,chickpea
22,72,85,18.86,15.65,6.89,84.45,chickpea
35,64,78,19.25,17.50,7.12,82.10,chickpea
28,70,82,18.10,16.20,6.95,90.40,chickpea
18,68,21,24.84,63.55,6.89,46.57,lentil
31,65,22,26.47,68.80,6.13,44.97,lentil
33,63,21,24.18,68.32,6.48,46.10,lentil
22,67,19,25.40,64.20,6.70,48.30,lentil
40,67,19,27.91,64.71,7.21,64.88,blackgram
23,72,21,29.94,65.34,7.15,73.49,blackgram
39,58,24,27.87,65.93,7.40,61.94,blackgram
35,62,20,28.50,66.10,6.90,68.20,blackgram
20,47,20,28.57,85.65,6.72,48.34,mungbean
28,52,22,27.45,86.20,6.90,52.10,mungbean
24,49,18,29.10,84.80,7.10,46.90,mungbean
22,55,20,18.52,21.57,5.78,135.25,kidneybeans
34,59,21,21.05,22.80,5.65,128.40,kidneybeans
19,53,19,19.40,20.90,5.92,142.10,kidneybeans`,
  },
  {
    id: 'cash_crops_data',
    name: 'Cash Crops & Plantation Soil File',
    description: 'High-value commercial crops: Cotton, Sugarcane, Jute, and Coffee requiring intensive potash and specialized microclimatic hydric regimes.',
    category: 'Curated Crop File',
    sampleCount: 400,
    cropCount: 4,
    crops: ['cotton', 'sugarcane', 'jute', 'coffee'],
    rawText: `N,P,K,temperature,humidity,ph,rainfall,label
118,48,19,24.12,81.18,6.80,72.48,cotton
133,47,24,24.40,79.19,7.20,90.44,cotton
104,49,23,24.81,81.67,6.86,93.95,cotton
120,46,20,25.10,80.50,7.10,84.20,cotton
115,50,22,23.90,82.30,6.95,88.10,cotton
150,60,80,27.50,85.20,6.50,180.40,sugarcane
160,55,75,28.20,83.80,6.80,195.10,sugarcane
145,65,85,26.90,87.00,6.20,175.80,sugarcane
155,58,78,27.80,84.50,6.65,188.00,sugarcane
78,46,38,24.81,79.76,6.83,164.73,jute
67,35,44,23.02,76.18,6.88,189.88,jute
74,49,38,23.31,71.45,7.48,164.49,jute
90,40,39,25.72,81.86,6.62,191.96,jute
91,21,26,26.33,57.36,7.26,191.65,coffee
107,21,26,26.45,55.32,7.23,144.68,coffee
83,38,35,25.70,52.88,7.18,136.73,coffee
108,24,31,24.12,56.18,6.43,147.27,coffee`,
  },
  {
    id: 'horticulture_orchard_data',
    name: 'Horticulture & Fruit Orchards Soil File',
    description: 'Soil data for high-potassium perennial fruit orchards: Apple, Banana, Mango, Grapes, and Orange with delicate micronutrient balance and pH selectivity.',
    category: 'Curated Crop File',
    sampleCount: 500,
    cropCount: 5,
    crops: ['apple', 'banana', 'mango', 'grapes', 'orange'],
    rawText: `N,P,K,temperature,humidity,ph,rainfall,label
20,134,199,21.18,92.65,5.55,110.66,apple
24,130,196,22.31,90.85,5.97,108.93,apple
36,125,202,23.63,91.80,6.13,114.12,apple
100,75,50,27.37,80.45,6.20,104.50,banana
107,72,55,28.10,79.20,6.40,98.20,banana
95,78,48,26.90,82.10,6.10,110.40,banana
20,20,30,31.20,50.10,5.80,95.40,mango
24,25,35,32.40,48.50,6.10,88.90,mango
18,22,28,30.80,52.00,5.60,102.10,mango
23,138,201,23.84,81.78,6.00,71.49,grapes
18,142,204,22.90,80.50,6.20,68.90,grapes
25,135,198,24.20,83.10,5.90,74.20,grapes
19,16,10,24.20,91.80,7.10,110.20,orange
22,20,12,25.10,89.50,7.30,105.40,orange
18,15,11,23.80,93.20,6.90,115.00,orange`,
  },
];
